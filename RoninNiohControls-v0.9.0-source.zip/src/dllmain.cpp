#define WIN32_LEAN_AND_MEAN
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>
#include <tlhelp32.h>
#include <dinput.h>
#include <hidsdi.h>
#include <xinput.h>

#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cwchar>
#include <iterator>

namespace {

constexpr char kModName[] = "RoninNiohControls";
constexpr char kVersion[] = "0.9.0-configurable-bindings";

HMODULE gThisModule = nullptr;
wchar_t gModuleDirectory[MAX_PATH]{};
wchar_t gLogPath[MAX_PATH]{};
wchar_t gIniPath[MAX_PATH]{};
SRWLOCK gLogLock = SRWLOCK_INIT;
SRWLOCK gActionLock = SRWLOCK_INIT;
SRWLOCK gXInputLock = SRWLOCK_INIT;
SRWLOCK gDirectInputLock = SRWLOCK_INIT;
SRWLOCK gHidLock = SRWLOCK_INIT;

bool gLogActionLookups = true;
bool gLogPressedActions = true;
bool gEnableFileLog = true;
bool gLogNativeDevices = true;
bool gLogInputModules = true;
bool gLogExecutableImports = true;
bool gLogXInputTransitions = true;
bool gLogDirectInputTransitions = true;
bool gLogHidTransitions = true;
bool gEnableNativeRemap = true;
bool gEnableDualSenseUsbRemap = true;
bool gEnableXInputRemap = true;
bool gLogRemapTransitions = true;
bool gPreserveL2R2Fire = true;
int gStyleSquareDirection = 1;
int gStyleTriangleDirection = 3;
int gStyleCrossDirection = 2;

using XInputGetStateFn = DWORD(WINAPI*)(DWORD, XINPUT_STATE*);
XInputGetStateFn gOriginalXInputGetState = nullptr;

struct XInputSnapshot {
    bool initialized{};
    WORD buttons{};
    BYTE leftTrigger{};
    BYTE rightTrigger{};
    int leftXBand{};
    int leftYBand{};
    int rightXBand{};
    int rightYBand{};
};

XInputSnapshot gXInputSnapshots[XUSER_MAX_COUNT]{};

using DirectInput8CreateFn = HRESULT(WINAPI*)(HINSTANCE, DWORD, REFIID, LPVOID*, LPUNKNOWN);
using DirectInputCreateDeviceFn = HRESULT(STDMETHODCALLTYPE*)(void*, REFGUID, void**, LPUNKNOWN);
using DirectInputSetDataFormatFn = HRESULT(STDMETHODCALLTYPE*)(void*, LPCDIDATAFORMAT);
using DirectInputGetDeviceStateFn = HRESULT(STDMETHODCALLTYPE*)(void*, DWORD, LPVOID);

DirectInput8CreateFn gOriginalDirectInput8Create = nullptr;
DirectInputCreateDeviceFn gOriginalDirectInputCreateDevice = nullptr;
DirectInputSetDataFormatFn gOriginalDirectInputSetDataFormat = nullptr;
DirectInputGetDeviceStateFn gOriginalDirectInputGetDeviceState = nullptr;

struct DirectInputDeviceRecord {
    void* device{};
    DWORD dataSize{};
    DWORD buttonOffsets[64]{};
    DWORD buttonCount{};
    DWORD axisOffsets[16]{};
    DWORD axisCount{};
    DWORD povOffsets[4]{};
    DWORD povCount{};
    LONG axisCenters[16]{};
    BYTE lastButtons[64]{};
    int lastAxisBands[16]{};
    DWORD lastPov[4]{};
    bool initialized{};
};

DirectInputDeviceRecord gDirectInputDevices[16]{};

using CreateFileWFn = HANDLE(WINAPI*)(LPCWSTR, DWORD, DWORD, LPSECURITY_ATTRIBUTES, DWORD, DWORD, HANDLE);
using ReadFileFn = BOOL(WINAPI*)(HANDLE, LPVOID, DWORD, LPDWORD, LPOVERLAPPED);
using HidDGetAttributesFn = BOOLEAN(WINAPI*)(HANDLE, PHIDD_ATTRIBUTES);
using GetOverlappedResultFn = BOOL(WINAPI*)(HANDLE, LPOVERLAPPED, LPDWORD, BOOL);
using GetOverlappedResultExFn = BOOL(WINAPI*)(HANDLE, LPOVERLAPPED, LPDWORD, DWORD, BOOL);
using GetQueuedCompletionStatusFn = BOOL(WINAPI*)(HANDLE, LPDWORD, PULONG_PTR, LPOVERLAPPED*, DWORD);
using GetQueuedCompletionStatusExFn = BOOL(WINAPI*)(HANDLE, LPOVERLAPPED_ENTRY, ULONG, PULONG, DWORD, BOOL);

CreateFileWFn gOriginalCreateFileW = nullptr;
ReadFileFn gOriginalReadFile = nullptr;
HidDGetAttributesFn gOriginalHidDGetAttributes = nullptr;
GetOverlappedResultFn gOriginalGetOverlappedResult = nullptr;
GetOverlappedResultExFn gOriginalGetOverlappedResultEx = nullptr;
GetQueuedCompletionStatusFn gOriginalGetQueuedCompletionStatus = nullptr;
GetQueuedCompletionStatusExFn gOriginalGetQueuedCompletionStatusEx = nullptr;

HANDLE gDualSenseHandles[8]{};

struct PendingHidRead {
    bool active{};
    HANDLE handle{};
    OVERLAPPED* overlapped{};
    BYTE* buffer{};
    DWORD requested{};
};

PendingHidRead gPendingHidReads[32]{};

struct DualSenseSnapshot {
    bool initialized{};
    BYTE buttons0{};
    BYTE buttons1{};
    BYTE buttons2{};
    BYTE leftTriggerBand{};
    BYTE rightTriggerBand{};
    int leftXBand{};
    int leftYBand{};
    int rightXBand{};
    int rightYBand{};
};

DualSenseSnapshot gDualSenseSnapshot{};

enum class RemapAction : BYTE {
    None,
    Counterspark,
    MartialSquare,
    MartialTriangle,
    MartialCross,
    StyleSquare,
    StyleTriangle,
    StyleCross,
    FlashAttack,
    GrapplingHook,
    VeiledArt,
};

enum PadButton : std::uint32_t {
    PadSquare = 1u << 0,
    PadCross = 1u << 1,
    PadCircle = 1u << 2,
    PadTriangle = 1u << 3,
    PadL1 = 1u << 4,
    PadR1 = 1u << 5,
    PadL2 = 1u << 6,
    PadR2 = 1u << 7,
    PadDPadUp = 1u << 8,
    PadDPadDown = 1u << 9,
    PadDPadLeft = 1u << 10,
    PadDPadRight = 1u << 11,
    PadL3 = 1u << 12,
    PadR3 = 1u << 13,
    PadCreate = 1u << 14,
    PadOptions = 1u << 15,
    PadTouchpad = 1u << 16,
    PadPS = 1u << 17,
    PadMute = 1u << 18,
};

struct BindingConfig {
    RemapAction action;
    const wchar_t* key;
    const wchar_t* defaultText;
    std::uint32_t defaultMask;
    std::uint32_t mask;
    bool enabled;
};

BindingConfig gBindings[] = {
    {RemapAction::Counterspark, L"Counterspark", L"R2", PadR2, PadR2, true},
    {RemapAction::GrapplingHook, L"GrapplingHook", L"Triangle", PadTriangle, PadTriangle, true},
    {RemapAction::MartialSquare, L"MartialSquare", L"L1+Square", PadL1 | PadSquare, PadL1 | PadSquare, true},
    {RemapAction::MartialTriangle, L"MartialTriangle", L"L1+Triangle", PadL1 | PadTriangle, PadL1 | PadTriangle, true},
    {RemapAction::MartialCross, L"MartialCross", L"L1+Cross", PadL1 | PadCross, PadL1 | PadCross, true},
    {RemapAction::VeiledArt, L"VeiledArt", L"L1+R1", PadL1 | PadR1, PadL1 | PadR1, true},
    {RemapAction::StyleSquare, L"StyleSquare", L"R1+Square", PadR1 | PadSquare, PadR1 | PadSquare, true},
    {RemapAction::StyleTriangle, L"StyleTriangle", L"R1+Triangle", PadR1 | PadTriangle, PadR1 | PadTriangle, true},
    {RemapAction::StyleCross, L"StyleCross", L"R1+Cross", PadR1 | PadCross, PadR1 | PadCross, true},
    {RemapAction::FlashAttack, L"FlashAttack", L"R1+Circle", PadR1 | PadCircle, PadR1 | PadCircle, true},
};

RemapAction gLastHidRemapAction = RemapAction::None;
RemapAction gLastXInputRemapActions[XUSER_MAX_COUNT]{};

void RecordRemapAction(RemapAction action, RemapAction& previous, const char* backend);

#pragma pack(push, 1)
struct InputDigitalActionData {
    bool state;
    bool active;
};

struct InputAnalogActionData {
    std::int32_t mode;
    float x;
    float y;
    bool active;
};
#pragma pack(pop)

static_assert(sizeof(InputDigitalActionData) == 2);
static_assert(sizeof(InputAnalogActionData) == 13);

using InputHandle = std::uint64_t;
using ActionHandle = std::uint64_t;

using GetActionSetHandleFn = ActionHandle(__fastcall*)(void*, const char*);
using GetDigitalActionHandleFn = ActionHandle(__fastcall*)(void*, const char*);
using GetDigitalActionDataFn = InputDigitalActionData(__fastcall*)(void*, InputHandle, ActionHandle);
using GetAnalogActionHandleFn = ActionHandle(__fastcall*)(void*, const char*);
using GetAnalogActionDataFn = InputAnalogActionData(__fastcall*)(void*, InputHandle, ActionHandle);

GetActionSetHandleFn gOriginalGetActionSetHandle = nullptr;
GetDigitalActionHandleFn gOriginalGetDigitalActionHandle = nullptr;
GetDigitalActionDataFn gOriginalGetDigitalActionData = nullptr;
GetAnalogActionHandleFn gOriginalGetAnalogActionHandle = nullptr;
GetAnalogActionDataFn gOriginalGetAnalogActionData = nullptr;

struct ActionRecord {
    ActionHandle handle{};
    char name[128]{};
    bool lastPressed{};
    bool hasLastPressed{};
};

ActionRecord gDigitalActions[512]{};
ActionRecord gAnalogActions[128]{};
std::size_t gDigitalActionCount = 0;
std::size_t gAnalogActionCount = 0;

void AppendPath(wchar_t* target, std::size_t capacity, const wchar_t* suffix) {
    const std::size_t used = std::wcslen(target);
    if (used + std::wcslen(suffix) + 1 < capacity) {
        std::wcscat(target, suffix);
    }
}

void InitializePaths() {
    wchar_t dllPath[MAX_PATH]{};
    GetModuleFileNameW(gThisModule, dllPath, MAX_PATH);

    std::wcsncpy(gModuleDirectory, dllPath, MAX_PATH - 1);
    wchar_t* slash = std::wcsrchr(gModuleDirectory, L'\\');
    if (slash) {
        *(slash + 1) = L'\0';
    }

    std::wcsncpy(gLogPath, gModuleDirectory, MAX_PATH - 1);
    AppendPath(gLogPath, MAX_PATH, L"RoninNiohControls.log");

    std::wcsncpy(gIniPath, gModuleDirectory, MAX_PATH - 1);
    AppendPath(gIniPath, MAX_PATH, L"RoninNiohControls.ini");
}

void Log(const char* format, ...) {
    if (!gEnableFileLog) return;

    char message[2048]{};
    va_list args;
    va_start(args, format);
    std::vsnprintf(message, sizeof(message), format, args);
    va_end(args);

    SYSTEMTIME time{};
    GetLocalTime(&time);

    char line[2304]{};
    std::snprintf(
        line,
        sizeof(line),
        "[%04u-%02u-%02u %02u:%02u:%02u.%03u] %s\r\n",
        time.wYear,
        time.wMonth,
        time.wDay,
        time.wHour,
        time.wMinute,
        time.wSecond,
        time.wMilliseconds,
        message);

    AcquireSRWLockExclusive(&gLogLock);
    HANDLE file = CreateFileW(
        gLogPath,
        FILE_APPEND_DATA,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr,
        OPEN_ALWAYS,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);
    if (file != INVALID_HANDLE_VALUE) {
        DWORD written = 0;
        WriteFile(file, line, static_cast<DWORD>(std::strlen(line)), &written, nullptr);
        CloseHandle(file);
    }
    ReleaseSRWLockExclusive(&gLogLock);
}

const wchar_t* SkipWideSpaces(const wchar_t* text) {
    while (text && (*text == L' ' || *text == L'\t')) ++text;
    return text;
}

std::uint32_t BindingTokenMask(const wchar_t* token) {
    if (!token || !*token) return 0;
    if (_wcsicmp(token, L"Square") == 0 || _wcsicmp(token, L"X") == 0) return PadSquare;
    if (_wcsicmp(token, L"Cross") == 0 || _wcsicmp(token, L"A") == 0) return PadCross;
    if (_wcsicmp(token, L"Circle") == 0 || _wcsicmp(token, L"B") == 0) return PadCircle;
    if (_wcsicmp(token, L"Triangle") == 0 || _wcsicmp(token, L"Y") == 0) return PadTriangle;
    if (_wcsicmp(token, L"L1") == 0 || _wcsicmp(token, L"LB") == 0) return PadL1;
    if (_wcsicmp(token, L"R1") == 0 || _wcsicmp(token, L"RB") == 0) return PadR1;
    if (_wcsicmp(token, L"L2") == 0 || _wcsicmp(token, L"LT") == 0) return PadL2;
    if (_wcsicmp(token, L"R2") == 0 || _wcsicmp(token, L"RT") == 0) return PadR2;
    if (_wcsicmp(token, L"DPadUp") == 0) return PadDPadUp;
    if (_wcsicmp(token, L"DPadDown") == 0) return PadDPadDown;
    if (_wcsicmp(token, L"DPadLeft") == 0) return PadDPadLeft;
    if (_wcsicmp(token, L"DPadRight") == 0) return PadDPadRight;
    if (_wcsicmp(token, L"L3") == 0 || _wcsicmp(token, L"LS") == 0) return PadL3;
    if (_wcsicmp(token, L"R3") == 0 || _wcsicmp(token, L"RS") == 0) return PadR3;
    if (_wcsicmp(token, L"Create") == 0 || _wcsicmp(token, L"View") == 0 || _wcsicmp(token, L"Back") == 0) return PadCreate;
    if (_wcsicmp(token, L"Options") == 0 || _wcsicmp(token, L"Menu") == 0 || _wcsicmp(token, L"Start") == 0) return PadOptions;
    if (_wcsicmp(token, L"Touchpad") == 0) return PadTouchpad;
    if (_wcsicmp(token, L"PS") == 0 || _wcsicmp(token, L"Guide") == 0) return PadPS;
    if (_wcsicmp(token, L"Mute") == 0) return PadMute;
    return 0;
}

bool ParseBindingText(const wchar_t* text, std::uint32_t& mask, bool& enabled) {
    mask = 0;
    enabled = false;
    const wchar_t* start = SkipWideSpaces(text);
    if (!start || !*start) return false;

    wchar_t whole[160]{};
    std::wcsncpy(whole, start, std::size(whole) - 1);
    std::size_t wholeLength = std::wcslen(whole);
    while (wholeLength && (whole[wholeLength - 1] == L' ' || whole[wholeLength - 1] == L'\t')) {
        whole[--wholeLength] = L'\0';
    }
    if (_wcsicmp(whole, L"None") == 0 || _wcsicmp(whole, L"Disabled") == 0 || _wcsicmp(whole, L"Off") == 0) {
        return true;
    }

    wchar_t* cursor = whole;
    while (*cursor) {
        wchar_t* separator = std::wcschr(cursor, L'+');
        if (separator) *separator = L'\0';

        wchar_t* tokenStart = cursor;
        while (*tokenStart == L' ' || *tokenStart == L'\t') ++tokenStart;
        wchar_t* tokenEnd = tokenStart + std::wcslen(tokenStart);
        while (tokenEnd > tokenStart && (tokenEnd[-1] == L' ' || tokenEnd[-1] == L'\t')) --tokenEnd;
        *tokenEnd = L'\0';

        const std::uint32_t tokenMask = BindingTokenMask(tokenStart);
        if (!tokenMask) return false;
        mask |= tokenMask;

        if (!separator) break;
        cursor = separator + 1;
        if (!*cursor) return false;
    }
    enabled = mask != 0;
    return enabled;
}

void LoadBindings() {
    for (BindingConfig& binding : gBindings) {
        wchar_t value[160]{};
        GetPrivateProfileStringW(
            L"Bindings",
            binding.key,
            binding.defaultText,
            value,
            static_cast<DWORD>(std::size(value)),
            gIniPath);

        std::uint32_t parsedMask = 0;
        bool enabled = false;
        if (ParseBindingText(value, parsedMask, enabled)) {
            binding.mask = parsedMask;
            binding.enabled = enabled;
        } else {
            binding.mask = binding.defaultMask;
            binding.enabled = true;
            char keyUtf8[128]{};
            char valueUtf8[320]{};
            WideCharToMultiByte(CP_UTF8, 0, binding.key, -1, keyUtf8, sizeof(keyUtf8), nullptr, nullptr);
            WideCharToMultiByte(CP_UTF8, 0, value, -1, valueUtf8, sizeof(valueUtf8), nullptr, nullptr);
            Log("CONFIG: invalid binding %s=%s; default restored.", keyUtf8, valueUtf8);
        }
    }
}

void LoadConfiguration() {
    gEnableFileLog = GetPrivateProfileIntW(L"Diagnostics", L"EnableFileLog", 1, gIniPath) != 0;
    gLogActionLookups = GetPrivateProfileIntW(L"Diagnostics", L"LogActionLookups", 1, gIniPath) != 0;
    gLogPressedActions = GetPrivateProfileIntW(L"Diagnostics", L"LogPressedActions", 1, gIniPath) != 0;
    gLogNativeDevices = GetPrivateProfileIntW(L"Diagnostics", L"LogNativeDevices", 1, gIniPath) != 0;
    gLogInputModules = GetPrivateProfileIntW(L"Diagnostics", L"LogInputModules", 1, gIniPath) != 0;
    gLogExecutableImports = GetPrivateProfileIntW(L"Diagnostics", L"LogExecutableImports", 1, gIniPath) != 0;
    gLogXInputTransitions = GetPrivateProfileIntW(L"Diagnostics", L"LogXInputTransitions", 1, gIniPath) != 0;
    gLogDirectInputTransitions = GetPrivateProfileIntW(L"Diagnostics", L"LogDirectInputTransitions", 1, gIniPath) != 0;
    gLogHidTransitions = GetPrivateProfileIntW(L"Diagnostics", L"LogHidTransitions", 1, gIniPath) != 0;
    gEnableNativeRemap = GetPrivateProfileIntW(L"Remap", L"Enable", 1, gIniPath) != 0;
    gEnableDualSenseUsbRemap = GetPrivateProfileIntW(L"Remap", L"EnableDualSenseUsb", 1, gIniPath) != 0;
    gEnableXInputRemap = GetPrivateProfileIntW(L"Remap", L"EnableXInput", 1, gIniPath) != 0;
    gLogRemapTransitions = GetPrivateProfileIntW(L"Remap", L"LogTransitions", 1, gIniPath) != 0;
    gPreserveL2R2Fire = GetPrivateProfileIntW(L"Remap", L"PreserveL2R2Fire", 1, gIniPath) != 0;
    gStyleSquareDirection = GetPrivateProfileIntW(L"Remap", L"StyleSquareDirection", 1, gIniPath);
    gStyleTriangleDirection = GetPrivateProfileIntW(L"Remap", L"StyleTriangleDirection", 3, gIniPath);
    gStyleCrossDirection = GetPrivateProfileIntW(L"Remap", L"StyleCrossDirection", 2, gIniPath);
    if (gStyleSquareDirection < 1 || gStyleSquareDirection > 3) gStyleSquareDirection = 1;
    if (gStyleTriangleDirection < 1 || gStyleTriangleDirection > 3) gStyleTriangleDirection = 3;
    if (gStyleCrossDirection < 1 || gStyleCrossDirection > 3) gStyleCrossDirection = 2;
    LoadBindings();
}

void WideToUtf8(const wchar_t* source, char* target, int targetSize) {
    if (!source || !target || targetSize <= 0) {
        return;
    }
    if (!WideCharToMultiByte(CP_UTF8, 0, source, -1, target, targetSize, nullptr, nullptr)) {
        std::strncpy(target, "<conversion failed>", static_cast<std::size_t>(targetSize) - 1);
    }
}

bool ContainsAsciiInsensitive(const char* text, const char* needle) {
    if (!text || !needle || !*needle) {
        return false;
    }
    for (const char* start = text; *start; ++start) {
        const char* a = start;
        const char* b = needle;
        while (*a && *b) {
            char ca = *a;
            char cb = *b;
            if (ca >= 'A' && ca <= 'Z') ca = static_cast<char>(ca - 'A' + 'a');
            if (cb >= 'A' && cb <= 'Z') cb = static_cast<char>(cb - 'A' + 'a');
            if (ca != cb) break;
            ++a;
            ++b;
        }
        if (!*b) return true;
    }
    return false;
}

bool IsInputRelatedName(const char* name) {
    constexpr const char* tokens[] = {
        "input", "xinput", "dinput", "gameinput", "hid", "steam", "sony", "dualsense", "pad", "sdl", "user32"
    };
    for (const char* token : tokens) {
        if (ContainsAsciiInsensitive(name, token)) return true;
    }
    return false;
}

void LogExecutableImports() {
    if (!gLogExecutableImports) return;

    auto* base = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(nullptr));
    if (!base) return;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0) {
        Log("NATIVE IMPORTS: invalid DOS header.");
        return;
    }
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) {
        Log("NATIVE IMPORTS: invalid 64-bit PE header.");
        return;
    }

    const IMAGE_DATA_DIRECTORY& directory = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    const DWORD imageSize = nt->OptionalHeader.SizeOfImage;
    if (!directory.VirtualAddress || !directory.Size || directory.VirtualAddress >= imageSize) {
        Log("NATIVE IMPORTS: executable has no static import table.");
        return;
    }

    Log("NATIVE IMPORTS BEGIN");
    auto* descriptor = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + directory.VirtualAddress);
    const std::size_t descriptorCount = directory.Size / sizeof(IMAGE_IMPORT_DESCRIPTOR);
    for (std::size_t descriptorIndex = 0; descriptorIndex < descriptorCount && descriptor[descriptorIndex].Name; ++descriptorIndex) {
        const IMAGE_IMPORT_DESCRIPTOR& current = descriptor[descriptorIndex];
        if (current.Name >= imageSize) continue;
        const char* dllName = reinterpret_cast<const char*>(base + current.Name);
        if (!IsInputRelatedName(dllName)) continue;
        Log("NATIVE IMPORT DLL: %s", dllName);

        // FirstThunk contains resolved function pointers after loading and is not safe to parse as RVAs.
        const DWORD thunkRva = current.OriginalFirstThunk;
        if (!thunkRva || thunkRva >= imageSize) {
            Log("  <function names unavailable; no original thunk table>");
            continue;
        }
        auto* thunk = reinterpret_cast<IMAGE_THUNK_DATA64*>(base + thunkRva);
        const std::size_t maximumThunks = (imageSize - thunkRva) / sizeof(IMAGE_THUNK_DATA64);
        for (std::size_t thunkIndex = 0; thunkIndex < maximumThunks && thunk[thunkIndex].u1.AddressOfData; ++thunkIndex) {
            const ULONGLONG thunkValue = thunk[thunkIndex].u1.AddressOfData;
            if (IMAGE_SNAP_BY_ORDINAL64(thunkValue)) {
                Log("  ordinal=%llu", static_cast<unsigned long long>(IMAGE_ORDINAL64(thunkValue)));
                continue;
            }
            if (thunkValue >= imageSize || thunkValue + sizeof(IMAGE_IMPORT_BY_NAME) >= imageSize) continue;
            auto* import = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + thunkValue);
            Log("  %s", reinterpret_cast<const char*>(import->Name));
        }
    }
    Log("NATIVE IMPORTS END");
}

void LogLoadedInputModules(const char* phase) {
    if (!gLogInputModules) return;

    HANDLE snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, GetCurrentProcessId());
    if (snapshot == INVALID_HANDLE_VALUE) {
        Log("NATIVE MODULES (%s): snapshot failed, error=%lu", phase, static_cast<unsigned long>(GetLastError()));
        return;
    }

    MODULEENTRY32W entry{};
    entry.dwSize = sizeof(entry);
    Log("NATIVE MODULES BEGIN (%s)", phase);
    if (Module32FirstW(snapshot, &entry)) {
        do {
            char moduleUtf8[MAX_PATH * 3]{};
            char pathUtf8[MAX_PATH * 3]{};
            WideToUtf8(entry.szModule, moduleUtf8, sizeof(moduleUtf8));
            if (!IsInputRelatedName(moduleUtf8)) continue;
            WideToUtf8(entry.szExePath, pathUtf8, sizeof(pathUtf8));
            Log("NATIVE MODULE: %s base=%p path=%s", moduleUtf8, entry.modBaseAddr, pathUtf8);
        } while (Module32NextW(snapshot, &entry));
    }
    Log("NATIVE MODULES END (%s)", phase);
    CloseHandle(snapshot);
}

const char* RawDeviceTypeName(DWORD type) {
    switch (type) {
        case RIM_TYPEMOUSE: return "mouse";
        case RIM_TYPEKEYBOARD: return "keyboard";
        case RIM_TYPEHID: return "hid";
        default: return "unknown";
    }
}

void LogNativeDevices(const char* phase) {
    if (!gLogNativeDevices) return;

    UINT count = 0;
    if (GetRawInputDeviceList(nullptr, &count, sizeof(RAWINPUTDEVICELIST)) == static_cast<UINT>(-1)) {
        Log("NATIVE DEVICES (%s): size query failed, error=%lu", phase, static_cast<unsigned long>(GetLastError()));
        return;
    }
    if (!count) {
        Log("NATIVE DEVICES (%s): no Raw Input devices found.", phase);
        return;
    }

    auto* devices = static_cast<RAWINPUTDEVICELIST*>(HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(RAWINPUTDEVICELIST) * count));
    if (!devices) return;
    UINT actual = count;
    if (GetRawInputDeviceList(devices, &actual, sizeof(RAWINPUTDEVICELIST)) == static_cast<UINT>(-1)) {
        Log("NATIVE DEVICES (%s): enumeration failed, error=%lu", phase, static_cast<unsigned long>(GetLastError()));
        HeapFree(GetProcessHeap(), 0, devices);
        return;
    }

    Log("NATIVE DEVICES BEGIN (%s), count=%u", phase, actual);
    for (UINT i = 0; i < actual; ++i) {
        RID_DEVICE_INFO info{};
        info.cbSize = sizeof(info);
        UINT infoSize = sizeof(info);
        if (GetRawInputDeviceInfoW(devices[i].hDevice, RIDI_DEVICEINFO, &info, &infoSize) == static_cast<UINT>(-1)) continue;

        UINT nameChars = 0;
        GetRawInputDeviceInfoW(devices[i].hDevice, RIDI_DEVICENAME, nullptr, &nameChars);
        wchar_t* name = nullptr;
        if (nameChars) {
            name = static_cast<wchar_t*>(HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(wchar_t) * (nameChars + 1)));
            if (name) {
                UINT capacity = nameChars;
                if (GetRawInputDeviceInfoW(devices[i].hDevice, RIDI_DEVICENAME, name, &capacity) == static_cast<UINT>(-1)) {
                    name[0] = L'\0';
                }
            }
        }

        char nameUtf8[1536]{};
        WideToUtf8(name ? name : L"<unavailable>", nameUtf8, sizeof(nameUtf8));
        if (info.dwType == RIM_TYPEHID) {
            Log(
                "NATIVE DEVICE: type=%s vid=0x%04lx pid=0x%04lx version=0x%04lx usagePage=0x%04x usage=0x%04x path=%s",
                RawDeviceTypeName(info.dwType),
                static_cast<unsigned long>(info.hid.dwVendorId),
                static_cast<unsigned long>(info.hid.dwProductId),
                static_cast<unsigned long>(info.hid.dwVersionNumber),
                info.hid.usUsagePage,
                info.hid.usUsage,
                nameUtf8);
        }
        if (name) HeapFree(GetProcessHeap(), 0, name);
    }
    Log("NATIVE DEVICES END (%s)", phase);
    HeapFree(GetProcessHeap(), 0, devices);
}

void LogNativeSnapshot(const char* phase) {
    LogLoadedInputModules(phase);
    LogNativeDevices(phase);
}

int AxisBand(SHORT value) {
    constexpr SHORT kThreshold = 14000;
    if (value <= -kThreshold) return -1;
    if (value >= kThreshold) return 1;
    return 0;
}

BYTE TriggerBand(BYTE value) {
    return value >= XINPUT_GAMEPAD_TRIGGER_THRESHOLD ? 1 : 0;
}

void FormatXInputButtons(WORD buttons, char* output, std::size_t outputSize) {
    if (!output || !outputSize) return;
    output[0] = '\0';
    struct ButtonName { WORD mask; const char* name; };
    constexpr ButtonName names[] = {
        {XINPUT_GAMEPAD_DPAD_UP, "DPadUp"},
        {XINPUT_GAMEPAD_DPAD_DOWN, "DPadDown"},
        {XINPUT_GAMEPAD_DPAD_LEFT, "DPadLeft"},
        {XINPUT_GAMEPAD_DPAD_RIGHT, "DPadRight"},
        {XINPUT_GAMEPAD_START, "Menu"},
        {XINPUT_GAMEPAD_BACK, "View"},
        {XINPUT_GAMEPAD_LEFT_THUMB, "L3"},
        {XINPUT_GAMEPAD_RIGHT_THUMB, "R3"},
        {XINPUT_GAMEPAD_LEFT_SHOULDER, "L1"},
        {XINPUT_GAMEPAD_RIGHT_SHOULDER, "R1"},
        {XINPUT_GAMEPAD_A, "Cross/A"},
        {XINPUT_GAMEPAD_B, "Circle/B"},
        {XINPUT_GAMEPAD_X, "Square/X"},
        {XINPUT_GAMEPAD_Y, "Triangle/Y"},
    };
    bool first = true;
    for (const ButtonName& item : names) {
        if (!(buttons & item.mask)) continue;
        if (!first) std::strncat(output, "+", outputSize - std::strlen(output) - 1);
        std::strncat(output, item.name, outputSize - std::strlen(output) - 1);
        first = false;
    }
    if (first) std::strncpy(output, "<none>", outputSize - 1);
}

void SetXInputStyleDirection(XINPUT_GAMEPAD& gamepad, int direction) {
    gamepad.sThumbRX = 0;
    gamepad.sThumbRY = 0;
    if (direction == 1) gamepad.sThumbRX = -32768;
    else if (direction == 2) gamepad.sThumbRY = -32768;
    else if (direction == 3) gamepad.sThumbRX = 32767;
}

int CountPadButtons(std::uint32_t mask) {
    int count = 0;
    while (mask) {
        mask &= mask - 1;
        ++count;
    }
    return count;
}

const BindingConfig* SelectBinding(std::uint32_t pressed) {
    const BindingConfig* best = nullptr;
    int bestCount = -1;
    for (const BindingConfig& binding : gBindings) {
        if (!binding.enabled || !binding.mask || (pressed & binding.mask) != binding.mask) continue;
        if (gPreserveL2R2Fire && binding.action == RemapAction::Counterspark &&
            (pressed & (PadL2 | PadR2)) == (PadL2 | PadR2) &&
            (binding.mask & PadR2) && !(binding.mask & PadL2)) {
            continue;
        }
        const int count = CountPadButtons(binding.mask);
        if (count > bestCount) {
            best = &binding;
            bestCount = count;
        }
    }
    return best;
}

std::uint32_t XInputPadMask(const XINPUT_GAMEPAD& gamepad) {
    std::uint32_t mask = 0;
    const WORD buttons = gamepad.wButtons;
    if (buttons & XINPUT_GAMEPAD_X) mask |= PadSquare;
    if (buttons & XINPUT_GAMEPAD_A) mask |= PadCross;
    if (buttons & XINPUT_GAMEPAD_B) mask |= PadCircle;
    if (buttons & XINPUT_GAMEPAD_Y) mask |= PadTriangle;
    if (buttons & XINPUT_GAMEPAD_LEFT_SHOULDER) mask |= PadL1;
    if (buttons & XINPUT_GAMEPAD_RIGHT_SHOULDER) mask |= PadR1;
    if (gamepad.bLeftTrigger) mask |= PadL2;
    if (gamepad.bRightTrigger) mask |= PadR2;
    if (buttons & XINPUT_GAMEPAD_DPAD_UP) mask |= PadDPadUp;
    if (buttons & XINPUT_GAMEPAD_DPAD_DOWN) mask |= PadDPadDown;
    if (buttons & XINPUT_GAMEPAD_DPAD_LEFT) mask |= PadDPadLeft;
    if (buttons & XINPUT_GAMEPAD_DPAD_RIGHT) mask |= PadDPadRight;
    if (buttons & XINPUT_GAMEPAD_LEFT_THUMB) mask |= PadL3;
    if (buttons & XINPUT_GAMEPAD_RIGHT_THUMB) mask |= PadR3;
    if (buttons & XINPUT_GAMEPAD_BACK) mask |= PadCreate;
    if (buttons & XINPUT_GAMEPAD_START) mask |= PadOptions;
    return mask;
}

void ClearXInputPadMask(XINPUT_GAMEPAD& gamepad, std::uint32_t mask) {
    WORD clear = 0;
    if (mask & PadSquare) clear |= XINPUT_GAMEPAD_X;
    if (mask & PadCross) clear |= XINPUT_GAMEPAD_A;
    if (mask & PadCircle) clear |= XINPUT_GAMEPAD_B;
    if (mask & PadTriangle) clear |= XINPUT_GAMEPAD_Y;
    if (mask & PadL1) clear |= XINPUT_GAMEPAD_LEFT_SHOULDER;
    if (mask & PadR1) clear |= XINPUT_GAMEPAD_RIGHT_SHOULDER;
    if (mask & PadDPadUp) clear |= XINPUT_GAMEPAD_DPAD_UP;
    if (mask & PadDPadDown) clear |= XINPUT_GAMEPAD_DPAD_DOWN;
    if (mask & PadDPadLeft) clear |= XINPUT_GAMEPAD_DPAD_LEFT;
    if (mask & PadDPadRight) clear |= XINPUT_GAMEPAD_DPAD_RIGHT;
    if (mask & PadL3) clear |= XINPUT_GAMEPAD_LEFT_THUMB;
    if (mask & PadR3) clear |= XINPUT_GAMEPAD_RIGHT_THUMB;
    if (mask & PadCreate) clear |= XINPUT_GAMEPAD_BACK;
    if (mask & PadOptions) clear |= XINPUT_GAMEPAD_START;
    gamepad.wButtons = static_cast<WORD>(gamepad.wButtons & ~clear);
    if (mask & PadL2) gamepad.bLeftTrigger = 0;
    if (mask & PadR2) gamepad.bRightTrigger = 0;
}

void SetXInputPadMask(XINPUT_GAMEPAD& gamepad, std::uint32_t mask) {
    if (mask & PadSquare) gamepad.wButtons |= XINPUT_GAMEPAD_X;
    if (mask & PadCross) gamepad.wButtons |= XINPUT_GAMEPAD_A;
    if (mask & PadCircle) gamepad.wButtons |= XINPUT_GAMEPAD_B;
    if (mask & PadTriangle) gamepad.wButtons |= XINPUT_GAMEPAD_Y;
    if (mask & PadL1) gamepad.wButtons |= XINPUT_GAMEPAD_LEFT_SHOULDER;
    if (mask & PadR1) gamepad.wButtons |= XINPUT_GAMEPAD_RIGHT_SHOULDER;
    if (mask & PadDPadUp) gamepad.wButtons |= XINPUT_GAMEPAD_DPAD_UP;
    if (mask & PadDPadDown) gamepad.wButtons |= XINPUT_GAMEPAD_DPAD_DOWN;
    if (mask & PadDPadLeft) gamepad.wButtons |= XINPUT_GAMEPAD_DPAD_LEFT;
    if (mask & PadDPadRight) gamepad.wButtons |= XINPUT_GAMEPAD_DPAD_RIGHT;
    if (mask & PadL3) gamepad.wButtons |= XINPUT_GAMEPAD_LEFT_THUMB;
    if (mask & PadR3) gamepad.wButtons |= XINPUT_GAMEPAD_RIGHT_THUMB;
    if (mask & PadCreate) gamepad.wButtons |= XINPUT_GAMEPAD_BACK;
    if (mask & PadOptions) gamepad.wButtons |= XINPUT_GAMEPAD_START;
    if (mask & PadL2) gamepad.bLeftTrigger = 255;
    if (mask & PadR2) gamepad.bRightTrigger = 255;
}

void ApplyXInputAction(XINPUT_GAMEPAD& gamepad, RemapAction action) {
    switch (action) {
        case RemapAction::Counterspark:
            SetXInputPadMask(gamepad, PadTriangle);
            break;
        case RemapAction::GrapplingHook:
            SetXInputPadMask(gamepad, PadR2);
            break;
        case RemapAction::MartialSquare:
            SetXInputPadMask(gamepad, PadR1 | PadSquare);
            break;
        case RemapAction::MartialTriangle:
            SetXInputPadMask(gamepad, PadR1 | PadTriangle);
            break;
        case RemapAction::MartialCross:
            SetXInputPadMask(gamepad, PadR1 | PadCross);
            break;
        case RemapAction::VeiledArt:
            SetXInputPadMask(gamepad, PadR1 | PadCircle);
            break;
        case RemapAction::StyleSquare:
            SetXInputPadMask(gamepad, PadR1);
            SetXInputStyleDirection(gamepad, gStyleSquareDirection);
            break;
        case RemapAction::StyleTriangle:
            SetXInputPadMask(gamepad, PadR1);
            SetXInputStyleDirection(gamepad, gStyleTriangleDirection);
            break;
        case RemapAction::StyleCross:
            SetXInputPadMask(gamepad, PadR1);
            SetXInputStyleDirection(gamepad, gStyleCrossDirection);
            break;
        case RemapAction::FlashAttack:
            SetXInputPadMask(gamepad, PadR1 | PadDPadUp);
            break;
        default:
            break;
    }
}

void ApplyXInputRemap(DWORD userIndex, XINPUT_GAMEPAD& gamepad) {
    if (!gEnableNativeRemap || !gEnableXInputRemap || userIndex >= XUSER_MAX_COUNT) return;
    const BindingConfig* binding = SelectBinding(XInputPadMask(gamepad));
    const RemapAction action = binding ? binding->action : RemapAction::None;
    if (binding) {
        ClearXInputPadMask(gamepad, binding->mask);
        ApplyXInputAction(gamepad, action);
    }
    RecordRemapAction(action, gLastXInputRemapActions[userIndex], "XInput");
}

DWORD WINAPI HookXInputGetState(DWORD userIndex, XINPUT_STATE* state) {
    const DWORD result = gOriginalXInputGetState(userIndex, state);
    if (result != ERROR_SUCCESS || !state || userIndex >= XUSER_MAX_COUNT) {
        return result;
    }

    if (gLogXInputTransitions) {
        XInputSnapshot current{};
        current.initialized = true;
        current.buttons = state->Gamepad.wButtons;
        current.leftTrigger = TriggerBand(state->Gamepad.bLeftTrigger);
        current.rightTrigger = TriggerBand(state->Gamepad.bRightTrigger);
        current.leftXBand = AxisBand(state->Gamepad.sThumbLX);
        current.leftYBand = AxisBand(state->Gamepad.sThumbLY);
        current.rightXBand = AxisBand(state->Gamepad.sThumbRX);
        current.rightYBand = AxisBand(state->Gamepad.sThumbRY);

        bool changed = false;
        AcquireSRWLockExclusive(&gXInputLock);
        XInputSnapshot& previous = gXInputSnapshots[userIndex];
        changed = !previous.initialized ||
            previous.buttons != current.buttons ||
            previous.leftTrigger != current.leftTrigger ||
            previous.rightTrigger != current.rightTrigger ||
            previous.leftXBand != current.leftXBand ||
            previous.leftYBand != current.leftYBand ||
            previous.rightXBand != current.rightXBand ||
            previous.rightYBand != current.rightYBand;
        if (changed) previous = current;
        ReleaseSRWLockExclusive(&gXInputLock);

        if (changed) {
            char buttonNames[256]{};
            FormatXInputButtons(current.buttons, buttonNames, sizeof(buttonNames));
            Log(
                "XINPUT state: user=%lu packet=%lu buttons=0x%04x [%s] LT=%u RT=%u LX=%d LY=%d RX=%d RY=%d",
                static_cast<unsigned long>(userIndex),
                static_cast<unsigned long>(state->dwPacketNumber),
                current.buttons,
                buttonNames,
                state->Gamepad.bLeftTrigger,
                state->Gamepad.bRightTrigger,
                current.leftXBand,
                current.leftYBand,
                current.rightXBand,
                current.rightYBand);
        }
    }
    ApplyXInputRemap(userIndex, state->Gamepad);
    return result;
}

bool InstallMainImportOrdinalHook(
    const char* targetDll,
    WORD targetOrdinal,
    void* replacement,
    void** original) {
    if (*original) return true;

    auto* base = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(nullptr));
    if (!base) return false;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0) return false;
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return false;

    const DWORD imageSize = nt->OptionalHeader.SizeOfImage;
    const IMAGE_DATA_DIRECTORY& directory = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!directory.VirtualAddress || directory.VirtualAddress >= imageSize) return false;

    auto* descriptors = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + directory.VirtualAddress);
    const std::size_t descriptorCount = directory.Size / sizeof(IMAGE_IMPORT_DESCRIPTOR);
    for (std::size_t descriptorIndex = 0; descriptorIndex < descriptorCount && descriptors[descriptorIndex].Name; ++descriptorIndex) {
        const IMAGE_IMPORT_DESCRIPTOR& descriptor = descriptors[descriptorIndex];
        if (descriptor.Name >= imageSize || !descriptor.OriginalFirstThunk || !descriptor.FirstThunk) continue;
        const char* dllName = reinterpret_cast<const char*>(base + descriptor.Name);
        if (lstrcmpiA(dllName, targetDll) != 0) continue;
        if (descriptor.OriginalFirstThunk >= imageSize || descriptor.FirstThunk >= imageSize) return false;

        auto* names = reinterpret_cast<IMAGE_THUNK_DATA64*>(base + descriptor.OriginalFirstThunk);
        auto* addresses = reinterpret_cast<IMAGE_THUNK_DATA64*>(base + descriptor.FirstThunk);
        const std::size_t maximumThunks = (imageSize - descriptor.OriginalFirstThunk) / sizeof(IMAGE_THUNK_DATA64);
        for (std::size_t index = 0; index < maximumThunks && names[index].u1.AddressOfData; ++index) {
            if (!IMAGE_SNAP_BY_ORDINAL64(names[index].u1.Ordinal)) continue;
            if (IMAGE_ORDINAL64(names[index].u1.Ordinal) != targetOrdinal) continue;

            void** slot = reinterpret_cast<void**>(&addresses[index].u1.Function);
            DWORD oldProtection = 0;
            if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &oldProtection)) return false;
            *original = *slot;
            *slot = replacement;
            FlushInstructionCache(GetCurrentProcess(), slot, sizeof(void*));
            DWORD ignored = 0;
            VirtualProtect(slot, sizeof(void*), oldProtection, &ignored);
            return true;
        }
    }
    return false;
}

bool InstallMainImportNameHook(
    const char* targetDll,
    const char* targetFunction,
    void* replacement,
    void** original) {
    if (*original) return true;

    auto* base = reinterpret_cast<std::uint8_t*>(GetModuleHandleW(nullptr));
    if (!base) return false;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE || dos->e_lfanew <= 0) return false;
    auto* nt = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE || nt->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR64_MAGIC) return false;

    const DWORD imageSize = nt->OptionalHeader.SizeOfImage;
    const IMAGE_DATA_DIRECTORY& directory = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (!directory.VirtualAddress || directory.VirtualAddress >= imageSize) return false;

    auto* descriptors = reinterpret_cast<IMAGE_IMPORT_DESCRIPTOR*>(base + directory.VirtualAddress);
    const std::size_t descriptorCount = directory.Size / sizeof(IMAGE_IMPORT_DESCRIPTOR);
    for (std::size_t descriptorIndex = 0; descriptorIndex < descriptorCount && descriptors[descriptorIndex].Name; ++descriptorIndex) {
        const IMAGE_IMPORT_DESCRIPTOR& descriptor = descriptors[descriptorIndex];
        if (descriptor.Name >= imageSize || !descriptor.OriginalFirstThunk || !descriptor.FirstThunk) continue;
        const char* dllName = reinterpret_cast<const char*>(base + descriptor.Name);
        if (lstrcmpiA(dllName, targetDll) != 0) continue;
        if (descriptor.OriginalFirstThunk >= imageSize || descriptor.FirstThunk >= imageSize) return false;

        auto* names = reinterpret_cast<IMAGE_THUNK_DATA64*>(base + descriptor.OriginalFirstThunk);
        auto* addresses = reinterpret_cast<IMAGE_THUNK_DATA64*>(base + descriptor.FirstThunk);
        const std::size_t maximumThunks = (imageSize - descriptor.OriginalFirstThunk) / sizeof(IMAGE_THUNK_DATA64);
        for (std::size_t index = 0; index < maximumThunks && names[index].u1.AddressOfData; ++index) {
            const ULONGLONG value = names[index].u1.AddressOfData;
            if (IMAGE_SNAP_BY_ORDINAL64(value) || value >= imageSize) continue;
            auto* import = reinterpret_cast<IMAGE_IMPORT_BY_NAME*>(base + value);
            if (std::strcmp(reinterpret_cast<const char*>(import->Name), targetFunction) != 0) continue;

            void** slot = reinterpret_cast<void**>(&addresses[index].u1.Function);
            DWORD oldProtection = 0;
            if (!VirtualProtect(slot, sizeof(void*), PAGE_READWRITE, &oldProtection)) return false;
            *original = *slot;
            *slot = replacement;
            FlushInstructionCache(GetCurrentProcess(), slot, sizeof(void*));
            DWORD ignored = 0;
            VirtualProtect(slot, sizeof(void*), oldProtection, &ignored);
            return true;
        }
    }
    return false;
}

bool ContainsWideInsensitive(const wchar_t* text, const wchar_t* needle) {
    if (!text || !needle || !*needle) return false;
    for (const wchar_t* start = text; *start; ++start) {
        const wchar_t* a = start;
        const wchar_t* b = needle;
        while (*a && *b) {
            wchar_t ca = *a;
            wchar_t cb = *b;
            if (ca >= L'a' && ca <= L'z') ca = static_cast<wchar_t>(ca - L'a' + L'A');
            if (cb >= L'a' && cb <= L'z') cb = static_cast<wchar_t>(cb - L'a' + L'A');
            if (ca != cb) break;
            ++a;
            ++b;
        }
        if (!*b) return true;
    }
    return false;
}

bool IsDualSensePath(const wchar_t* path) {
    return path &&
        ContainsWideInsensitive(path, L"VID_054C") &&
        (ContainsWideInsensitive(path, L"PID_0CE6") || ContainsWideInsensitive(path, L"PID_0DF2"));
}

bool IsDualSenseHandle(HANDLE handle) {
    bool found = false;
    AcquireSRWLockShared(&gHidLock);
    for (HANDLE tracked : gDualSenseHandles) {
        if (tracked == handle) {
            found = true;
            break;
        }
    }
    ReleaseSRWLockShared(&gHidLock);
    return found;
}

void TrackDualSenseHandle(HANDLE handle, const char* reason) {
    if (!handle || handle == INVALID_HANDLE_VALUE) return;
    bool added = false;
    AcquireSRWLockExclusive(&gHidLock);
    for (HANDLE tracked : gDualSenseHandles) {
        if (tracked == handle) {
            ReleaseSRWLockExclusive(&gHidLock);
            return;
        }
    }
    for (HANDLE& tracked : gDualSenseHandles) {
        if (!tracked) {
            tracked = handle;
            added = true;
            break;
        }
    }
    ReleaseSRWLockExclusive(&gHidLock);
    if (added) Log("HID DualSense handle identified: handle=%p via=%s", handle, reason);
}

int DualSenseAxisBand(BYTE value) {
    if (value < 80) return -1;
    if (value > 176) return 1;
    return 0;
}

void FormatDualSenseButtons(BYTE buttons0, BYTE buttons1, BYTE buttons2, char* output, std::size_t outputSize) {
    if (!output || !outputSize) return;
    output[0] = '\0';
    bool first = true;
    auto append = [&](const char* name) {
        if (!first) std::strncat(output, "+", outputSize - std::strlen(output) - 1);
        std::strncat(output, name, outputSize - std::strlen(output) - 1);
        first = false;
    };

    const BYTE hat = buttons0 & 0x0F;
    if (hat == 0 || hat == 1 || hat == 7) append("DPadUp");
    if (hat == 1 || hat == 2 || hat == 3) append("DPadRight");
    if (hat == 3 || hat == 4 || hat == 5) append("DPadDown");
    if (hat == 5 || hat == 6 || hat == 7) append("DPadLeft");
    if (buttons0 & 0x10) append("Square");
    if (buttons0 & 0x20) append("Cross");
    if (buttons0 & 0x40) append("Circle");
    if (buttons0 & 0x80) append("Triangle");
    if (buttons1 & 0x01) append("L1");
    if (buttons1 & 0x02) append("R1");
    if (buttons1 & 0x04) append("L2Digital");
    if (buttons1 & 0x08) append("R2Digital");
    if (buttons1 & 0x10) append("Create");
    if (buttons1 & 0x20) append("Options");
    if (buttons1 & 0x40) append("L3");
    if (buttons1 & 0x80) append("R3");
    if (buttons2 & 0x01) append("PS");
    if (buttons2 & 0x02) append("Touchpad");
    if (buttons2 & 0x04) append("Mute");
    if (first) std::strncpy(output, "<none>", outputSize - 1);
}

void DecodeDualSenseReport(const BYTE* data, DWORD size, const char* mode) {
    if (!data || !gLogHidTransitions) return;
    const BYTE* common = nullptr;
    if (size >= 64 && data[0] == 0x01) {
        common = data + 1;
    } else if (size >= 12 && data[0] == 0x31) {
        common = data + 2;
    } else {
        return;
    }

    DualSenseSnapshot current{};
    current.initialized = true;
    current.leftXBand = DualSenseAxisBand(common[0]);
    current.leftYBand = DualSenseAxisBand(common[1]);
    current.rightXBand = DualSenseAxisBand(common[2]);
    current.rightYBand = DualSenseAxisBand(common[3]);
    current.leftTriggerBand = common[4] >= 30 ? 1 : 0;
    current.rightTriggerBand = common[5] >= 30 ? 1 : 0;
    current.buttons0 = common[7];
    current.buttons1 = common[8];
    current.buttons2 = common[9];

    bool changed = false;
    AcquireSRWLockExclusive(&gHidLock);
    changed = !gDualSenseSnapshot.initialized ||
        gDualSenseSnapshot.buttons0 != current.buttons0 ||
        gDualSenseSnapshot.buttons1 != current.buttons1 ||
        gDualSenseSnapshot.buttons2 != current.buttons2 ||
        gDualSenseSnapshot.leftTriggerBand != current.leftTriggerBand ||
        gDualSenseSnapshot.rightTriggerBand != current.rightTriggerBand ||
        gDualSenseSnapshot.leftXBand != current.leftXBand ||
        gDualSenseSnapshot.leftYBand != current.leftYBand ||
        gDualSenseSnapshot.rightXBand != current.rightXBand ||
        gDualSenseSnapshot.rightYBand != current.rightYBand;
    if (changed) gDualSenseSnapshot = current;
    ReleaseSRWLockExclusive(&gHidLock);

    if (changed) {
        char buttons[320]{};
        FormatDualSenseButtons(current.buttons0, current.buttons1, current.buttons2, buttons, sizeof(buttons));
        Log(
            "HID state: mode=%s report=0x%02x size=%lu buttons=[%s] LT=%u RT=%u LX=%d LY=%d RX=%d RY=%d",
            mode,
            data[0],
            static_cast<unsigned long>(size),
            buttons,
            common[4],
            common[5],
            current.leftXBand,
            current.leftYBand,
            current.rightXBand,
            current.rightYBand);
    }
}

const char* RemapActionName(RemapAction action) {
    switch (action) {
        case RemapAction::Counterspark: return "Counterspark -> native Triangle/Y";
        case RemapAction::MartialSquare: return "MartialSquare -> native R1/RB+Square/X";
        case RemapAction::MartialTriangle: return "MartialTriangle -> native R1/RB+Triangle/Y";
        case RemapAction::MartialCross: return "MartialCross -> native R1/RB+Cross/A";
        case RemapAction::StyleSquare: return "StyleSquare -> native R1/RB+RightStick direction";
        case RemapAction::StyleTriangle: return "StyleTriangle -> native R1/RB+RightStick direction";
        case RemapAction::StyleCross: return "StyleCross -> native R1/RB+RightStick direction";
        case RemapAction::FlashAttack: return "FlashAttack -> native R1/RB+DPadUp";
        case RemapAction::GrapplingHook: return "GrapplingHook -> native R2/RT";
        case RemapAction::VeiledArt: return "VeiledArt -> native R1/RB+Circle/B";
        default: return "none";
    }
}

void RecordRemapAction(RemapAction action, RemapAction& previous, const char* backend) {
    bool changed = false;
    AcquireSRWLockExclusive(&gHidLock);
    if (previous != action) {
        previous = action;
        changed = true;
    }
    ReleaseSRWLockExclusive(&gHidLock);
    if (changed && action != RemapAction::None && gLogRemapTransitions) {
        Log("REMAP[%s]: %s", backend, RemapActionName(action));
    }
}

void SetStyleDirection(BYTE* common, int direction) {
    // Rise of the Ronin places its three equipped styles at left, down and right.
    common[2] = 128;
    common[3] = 128;
    if (direction == 1) common[2] = 0;
    else if (direction == 2) common[3] = 255;
    else if (direction == 3) common[2] = 255;
}

std::uint32_t HidPadMask(const BYTE* common) {
    std::uint32_t mask = 0;
    const BYTE buttons0 = common[7];
    const BYTE buttons1 = common[8];
    const BYTE buttons2 = common[9];
    const BYTE hat = buttons0 & 0x0F;
    if (buttons0 & 0x10) mask |= PadSquare;
    if (buttons0 & 0x20) mask |= PadCross;
    if (buttons0 & 0x40) mask |= PadCircle;
    if (buttons0 & 0x80) mask |= PadTriangle;
    if (buttons1 & 0x01) mask |= PadL1;
    if (buttons1 & 0x02) mask |= PadR1;
    if ((buttons1 & 0x04) || common[4]) mask |= PadL2;
    if ((buttons1 & 0x08) || common[5]) mask |= PadR2;
    if (buttons1 & 0x10) mask |= PadCreate;
    if (buttons1 & 0x20) mask |= PadOptions;
    if (buttons1 & 0x40) mask |= PadL3;
    if (buttons1 & 0x80) mask |= PadR3;
    if (buttons2 & 0x01) mask |= PadPS;
    if (buttons2 & 0x02) mask |= PadTouchpad;
    if (buttons2 & 0x04) mask |= PadMute;
    if (hat == 0 || hat == 1 || hat == 7) mask |= PadDPadUp;
    if (hat == 1 || hat == 2 || hat == 3) mask |= PadDPadRight;
    if (hat == 3 || hat == 4 || hat == 5) mask |= PadDPadDown;
    if (hat == 5 || hat == 6 || hat == 7) mask |= PadDPadLeft;
    return mask;
}

void ClearHidPadMask(BYTE* common, std::uint32_t mask) {
    BYTE& buttons0 = common[7];
    BYTE& buttons1 = common[8];
    BYTE& buttons2 = common[9];
    if (mask & PadSquare) buttons0 &= ~0x10;
    if (mask & PadCross) buttons0 &= ~0x20;
    if (mask & PadCircle) buttons0 &= ~0x40;
    if (mask & PadTriangle) buttons0 &= ~0x80;
    if (mask & PadL1) buttons1 &= ~0x01;
    if (mask & PadR1) buttons1 &= ~0x02;
    if (mask & PadL2) {
        buttons1 &= ~0x04;
        common[4] = 0;
    }
    if (mask & PadR2) {
        buttons1 &= ~0x08;
        common[5] = 0;
    }
    if (mask & PadCreate) buttons1 &= ~0x10;
    if (mask & PadOptions) buttons1 &= ~0x20;
    if (mask & PadL3) buttons1 &= ~0x40;
    if (mask & PadR3) buttons1 &= ~0x80;
    if (mask & PadPS) buttons2 &= ~0x01;
    if (mask & PadTouchpad) buttons2 &= ~0x02;
    if (mask & PadMute) buttons2 &= ~0x04;
    if (mask & (PadDPadUp | PadDPadDown | PadDPadLeft | PadDPadRight)) {
        buttons0 = static_cast<BYTE>((buttons0 & 0xF0) | 0x08);
    }
}

BYTE HidHatForMask(std::uint32_t mask) {
    const bool up = (mask & PadDPadUp) != 0;
    const bool down = (mask & PadDPadDown) != 0;
    const bool left = (mask & PadDPadLeft) != 0;
    const bool right = (mask & PadDPadRight) != 0;
    if (up && right) return 1;
    if (down && right) return 3;
    if (down && left) return 5;
    if (up && left) return 7;
    if (up) return 0;
    if (right) return 2;
    if (down) return 4;
    if (left) return 6;
    return 8;
}

void SetHidPadMask(BYTE* common, std::uint32_t mask) {
    BYTE& buttons0 = common[7];
    BYTE& buttons1 = common[8];
    BYTE& buttons2 = common[9];
    if (mask & PadSquare) buttons0 |= 0x10;
    if (mask & PadCross) buttons0 |= 0x20;
    if (mask & PadCircle) buttons0 |= 0x40;
    if (mask & PadTriangle) buttons0 |= 0x80;
    if (mask & PadL1) buttons1 |= 0x01;
    if (mask & PadR1) buttons1 |= 0x02;
    if (mask & PadL2) {
        buttons1 |= 0x04;
        common[4] = 255;
    }
    if (mask & PadR2) {
        buttons1 |= 0x08;
        common[5] = 255;
    }
    if (mask & PadCreate) buttons1 |= 0x10;
    if (mask & PadOptions) buttons1 |= 0x20;
    if (mask & PadL3) buttons1 |= 0x40;
    if (mask & PadR3) buttons1 |= 0x80;
    if (mask & PadPS) buttons2 |= 0x01;
    if (mask & PadTouchpad) buttons2 |= 0x02;
    if (mask & PadMute) buttons2 |= 0x04;
    if (mask & (PadDPadUp | PadDPadDown | PadDPadLeft | PadDPadRight)) {
        buttons0 = static_cast<BYTE>((buttons0 & 0xF0) | HidHatForMask(mask));
    }
}

void ApplyHidAction(BYTE* common, RemapAction action) {
    switch (action) {
        case RemapAction::Counterspark:
            SetHidPadMask(common, PadTriangle);
            break;
        case RemapAction::GrapplingHook:
            SetHidPadMask(common, PadR2);
            break;
        case RemapAction::MartialSquare:
            SetHidPadMask(common, PadR1 | PadSquare);
            break;
        case RemapAction::MartialTriangle:
            SetHidPadMask(common, PadR1 | PadTriangle);
            break;
        case RemapAction::MartialCross:
            SetHidPadMask(common, PadR1 | PadCross);
            break;
        case RemapAction::VeiledArt:
            SetHidPadMask(common, PadR1 | PadCircle);
            break;
        case RemapAction::StyleSquare:
            SetHidPadMask(common, PadR1);
            SetStyleDirection(common, gStyleSquareDirection);
            break;
        case RemapAction::StyleTriangle:
            SetHidPadMask(common, PadR1);
            SetStyleDirection(common, gStyleTriangleDirection);
            break;
        case RemapAction::StyleCross:
            SetHidPadMask(common, PadR1);
            SetStyleDirection(common, gStyleCrossDirection);
            break;
        case RemapAction::FlashAttack:
            SetHidPadMask(common, PadR1 | PadDPadUp);
            break;
        default:
            break;
    }
}

void ApplyNativeRemapToUsbReport(BYTE* data, DWORD size) {
    if (!gEnableNativeRemap || !gEnableDualSenseUsbRemap || !data || size < 64 || data[0] != 0x01) return;

    BYTE* common = data + 1;
    const BindingConfig* binding = SelectBinding(HidPadMask(common));
    const RemapAction action = binding ? binding->action : RemapAction::None;
    if (binding) {
        ClearHidPadMask(common, binding->mask);
        ApplyHidAction(common, action);
    }
    RecordRemapAction(action, gLastHidRemapAction, "DualSenseUSB");
}

void ProcessDualSenseInput(BYTE* data, DWORD size, const char* mode) {
    if (!data || !size) return;

    // ReadFile may return several complete 64-byte USB reports in one buffer.
    if (size >= 64 && size % 64 == 0) {
        bool usbBatch = true;
        for (DWORD offset = 0; offset < size; offset += 64) {
            if (data[offset] != 0x01) {
                usbBatch = false;
                break;
            }
        }
        if (usbBatch) {
            for (DWORD offset = 0; offset < size; offset += 64) {
                BYTE* report = data + offset;
                DecodeDualSenseReport(report, 64, mode);
                ApplyNativeRemapToUsbReport(report, 64);
            }
            return;
        }
    }

    DecodeDualSenseReport(data, size, mode);
    ApplyNativeRemapToUsbReport(data, size);
}

void RememberPendingHidRead(HANDLE handle, OVERLAPPED* overlapped, BYTE* buffer, DWORD requested) {
    if (!overlapped || !buffer) return;
    AcquireSRWLockExclusive(&gHidLock);
    PendingHidRead* empty = nullptr;
    for (PendingHidRead& pending : gPendingHidReads) {
        if (pending.active && pending.overlapped == overlapped) {
            pending.handle = handle;
            pending.buffer = buffer;
            pending.requested = requested;
            ReleaseSRWLockExclusive(&gHidLock);
            return;
        }
        if (!pending.active && !empty) empty = &pending;
    }
    if (empty) {
        empty->active = true;
        empty->handle = handle;
        empty->overlapped = overlapped;
        empty->buffer = buffer;
        empty->requested = requested;
    }
    ReleaseSRWLockExclusive(&gHidLock);
}

bool TakePendingHidRead(OVERLAPPED* overlapped, PendingHidRead& output) {
    if (!overlapped) return false;
    bool found = false;
    AcquireSRWLockExclusive(&gHidLock);
    for (PendingHidRead& pending : gPendingHidReads) {
        if (pending.active && pending.overlapped == overlapped) {
            output = pending;
            pending.active = false;
            found = true;
            break;
        }
    }
    ReleaseSRWLockExclusive(&gHidLock);
    return found;
}

void CompletePendingHidRead(OVERLAPPED* overlapped, DWORD transferred, const char* mode) {
    PendingHidRead pending{};
    if (!TakePendingHidRead(overlapped, pending)) return;
    if (!transferred || transferred > pending.requested) {
        Log(
            "HID completion ignored invalid length: mode=%s transferred=%lu requested=%lu",
            mode,
            static_cast<unsigned long>(transferred),
            static_cast<unsigned long>(pending.requested));
        return;
    }
    ProcessDualSenseInput(pending.buffer, transferred, mode);
}

BOOL WINAPI HookGetOverlappedResult(HANDLE file, LPOVERLAPPED overlapped, LPDWORD transferred, BOOL wait) {
    const BOOL result = gOriginalGetOverlappedResult(file, overlapped, transferred, wait);
    const DWORD originalError = GetLastError();
    if (result && transferred && IsDualSenseHandle(file)) {
        CompletePendingHidRead(overlapped, *transferred, "GetOverlappedResult");
    }
    SetLastError(originalError);
    return result;
}

BOOL WINAPI HookGetOverlappedResultEx(
    HANDLE file,
    LPOVERLAPPED overlapped,
    LPDWORD transferred,
    DWORD milliseconds,
    BOOL alertable) {
    const BOOL result = gOriginalGetOverlappedResultEx(file, overlapped, transferred, milliseconds, alertable);
    const DWORD originalError = GetLastError();
    if (result && transferred && IsDualSenseHandle(file)) {
        CompletePendingHidRead(overlapped, *transferred, "GetOverlappedResultEx");
    }
    SetLastError(originalError);
    return result;
}

BOOL WINAPI HookGetQueuedCompletionStatus(
    HANDLE completionPort,
    LPDWORD transferred,
    PULONG_PTR completionKey,
    LPOVERLAPPED* overlapped,
    DWORD milliseconds) {
    const BOOL result = gOriginalGetQueuedCompletionStatus(completionPort, transferred, completionKey, overlapped, milliseconds);
    const DWORD originalError = GetLastError();
    if (result && transferred && overlapped && *overlapped) {
        CompletePendingHidRead(*overlapped, *transferred, "GetQueuedCompletionStatus");
    }
    SetLastError(originalError);
    return result;
}

BOOL WINAPI HookGetQueuedCompletionStatusEx(
    HANDLE completionPort,
    LPOVERLAPPED_ENTRY entries,
    ULONG count,
    PULONG removed,
    DWORD milliseconds,
    BOOL alertable) {
    const BOOL result = gOriginalGetQueuedCompletionStatusEx(completionPort, entries, count, removed, milliseconds, alertable);
    const DWORD originalError = GetLastError();
    if (result && entries && removed) {
        for (ULONG i = 0; i < *removed; ++i) {
            CompletePendingHidRead(
                entries[i].lpOverlapped,
                entries[i].dwNumberOfBytesTransferred,
                "GetQueuedCompletionStatusEx");
        }
    }
    SetLastError(originalError);
    return result;
}

DWORD WINAPI PendingHidMonitorThread(void*) {
    while (true) {
        for (std::size_t i = 0; i < std::size(gPendingHidReads); ++i) {
            PendingHidRead copy{};
            AcquireSRWLockShared(&gHidLock);
            copy = gPendingHidReads[i];
            ReleaseSRWLockShared(&gHidLock);
            if (!copy.active) continue;

            DWORD transferred = 0;
            if (GetOverlappedResult(copy.handle, copy.overlapped, &transferred, FALSE)) {
                AcquireSRWLockExclusive(&gHidLock);
                if (gPendingHidReads[i].overlapped == copy.overlapped) gPendingHidReads[i].active = false;
                ReleaseSRWLockExclusive(&gHidLock);
                DecodeDualSenseReport(copy.buffer, transferred, "overlapped");
            } else {
                const DWORD error = GetLastError();
                if (error != ERROR_IO_INCOMPLETE && error != ERROR_IO_PENDING) {
                    AcquireSRWLockExclusive(&gHidLock);
                    if (gPendingHidReads[i].overlapped == copy.overlapped) gPendingHidReads[i].active = false;
                    ReleaseSRWLockExclusive(&gHidLock);
                }
            }
        }
        Sleep(1);
    }
}

HANDLE WINAPI HookCreateFileW(
    LPCWSTR path,
    DWORD desiredAccess,
    DWORD shareMode,
    LPSECURITY_ATTRIBUTES security,
    DWORD creationDisposition,
    DWORD flags,
    HANDLE templateFile) {
    HANDLE handle = gOriginalCreateFileW(path, desiredAccess, shareMode, security, creationDisposition, flags, templateFile);
    if (handle != INVALID_HANDLE_VALUE && IsDualSensePath(path)) {
        TrackDualSenseHandle(handle, "CreateFileW path");
    }
    return handle;
}

BOOLEAN WINAPI HookHidDGetAttributes(HANDLE device, PHIDD_ATTRIBUTES attributes) {
    const BOOLEAN result = gOriginalHidDGetAttributes(device, attributes);
    if (result && attributes && attributes->VendorID == 0x054C &&
        (attributes->ProductID == 0x0CE6 || attributes->ProductID == 0x0DF2)) {
        TrackDualSenseHandle(device, "HidD_GetAttributes");
    }
    return result;
}

BOOL WINAPI HookReadFile(HANDLE file, LPVOID buffer, DWORD requested, LPDWORD bytesRead, LPOVERLAPPED overlapped) {
    const bool trackedDualSense = buffer && IsDualSenseHandle(file);
    if (trackedDualSense && overlapped) {
        // Register before calling ReadFile so a very fast IOCP completion cannot race ahead of us.
        RememberPendingHidRead(file, overlapped, static_cast<BYTE*>(buffer), requested);
    }

    const BOOL result = gOriginalReadFile(file, buffer, requested, bytesRead, overlapped);
    const DWORD originalError = GetLastError();
    if (!trackedDualSense) {
        SetLastError(originalError);
        return result;
    }

    if (result) {
        PendingHidRead ignored{};
        if (overlapped) TakePendingHidRead(overlapped, ignored);

        DWORD transferred = bytesRead ? *bytesRead : 0;
        if (!transferred && overlapped && overlapped->InternalHigh <= requested) {
            transferred = static_cast<DWORD>(overlapped->InternalHigh);
        }
        // DualSense USB input reports are 64 bytes. Never substitute a larger caller
        // buffer size (commonly 320/384 bytes) for an unavailable transfer count.
        if (!transferred && requested >= 64) transferred = 64;
        ProcessDualSenseInput(static_cast<BYTE*>(buffer), transferred, overlapped ? "overlapped-immediate" : "synchronous");
    } else if (originalError != ERROR_IO_PENDING && overlapped) {
        PendingHidRead ignored{};
        TakePendingHidRead(overlapped, ignored);
    }
    SetLastError(originalError);
    return result;
}

bool InstallHidHooks() {
    const bool createInstalled = InstallMainImportNameHook(
        "KERNEL32.dll",
        "CreateFileW",
        reinterpret_cast<void*>(&HookCreateFileW),
        reinterpret_cast<void**>(&gOriginalCreateFileW));
    const bool readInstalled = InstallMainImportNameHook(
        "KERNEL32.dll",
        "ReadFile",
        reinterpret_cast<void*>(&HookReadFile),
        reinterpret_cast<void**>(&gOriginalReadFile));
    const bool attributesInstalled = InstallMainImportNameHook(
        "HID.DLL",
        "HidD_GetAttributes",
        reinterpret_cast<void*>(&HookHidDGetAttributes),
        reinterpret_cast<void**>(&gOriginalHidDGetAttributes));
    const bool overlappedInstalled = InstallMainImportNameHook(
        "KERNEL32.dll",
        "GetOverlappedResult",
        reinterpret_cast<void*>(&HookGetOverlappedResult),
        reinterpret_cast<void**>(&gOriginalGetOverlappedResult));
    const bool overlappedExInstalled = InstallMainImportNameHook(
        "KERNEL32.dll",
        "GetOverlappedResultEx",
        reinterpret_cast<void*>(&HookGetOverlappedResultEx),
        reinterpret_cast<void**>(&gOriginalGetOverlappedResultEx));
    const bool queuedInstalled = InstallMainImportNameHook(
        "KERNEL32.dll",
        "GetQueuedCompletionStatus",
        reinterpret_cast<void*>(&HookGetQueuedCompletionStatus),
        reinterpret_cast<void**>(&gOriginalGetQueuedCompletionStatus));
    const bool queuedExInstalled = InstallMainImportNameHook(
        "KERNEL32.dll",
        "GetQueuedCompletionStatusEx",
        reinterpret_cast<void*>(&HookGetQueuedCompletionStatusEx),
        reinterpret_cast<void**>(&gOriginalGetQueuedCompletionStatusEx));

    Log(
        "HID hooks: CreateFileW=%d ReadFile=%d HidD_GetAttributes=%d; write/output APIs untouched.",
        createInstalled ? 1 : 0,
        readInstalled ? 1 : 0,
        attributesInstalled ? 1 : 0);
    Log(
        "HID completion hooks: GetOverlappedResult=%d GetOverlappedResultEx=%d GetQueuedCompletionStatus=%d GetQueuedCompletionStatusEx=%d; polling disabled.",
        overlappedInstalled ? 1 : 0,
        overlappedExInstalled ? 1 : 0,
        queuedInstalled ? 1 : 0,
        queuedExInstalled ? 1 : 0);
    return readInstalled && (createInstalled || attributesInstalled);
}

bool InstallXInputHook() {
    const bool ordinalInstalled = InstallMainImportOrdinalHook(
        "XINPUT1_4.dll",
        2,
        reinterpret_cast<void*>(&HookXInputGetState),
        reinterpret_cast<void**>(&gOriginalXInputGetState));
    const bool nameInstalled = ordinalInstalled ? false : InstallMainImportNameHook(
        "XINPUT1_4.dll",
        "XInputGetState",
        reinterpret_cast<void*>(&HookXInputGetState),
        reinterpret_cast<void**>(&gOriginalXInputGetState));
    const bool installed = ordinalInstalled || nameInstalled;
    if (!installed) {
        Log("NOTICE: XInputGetState import hook was not installed.");
        return false;
    }
    Log(
        "XInputGetState hook installed on XINPUT1_4 via %s.",
        ordinalInstalled ? "ordinal 2" : "function name");
    Log("XInputSetState/rumble output on ordinal 3 is deliberately untouched.");
    return true;
}

void RememberAction(ActionRecord* records, std::size_t capacity, std::size_t& count, ActionHandle handle, const char* name) {
    if (!handle || !name || !*name) {
        return;
    }

    AcquireSRWLockExclusive(&gActionLock);
    for (std::size_t i = 0; i < count; ++i) {
        if (records[i].handle == handle) {
            ReleaseSRWLockExclusive(&gActionLock);
            return;
        }
    }

    if (count < capacity) {
        records[count].handle = handle;
        std::strncpy(records[count].name, name, sizeof(records[count].name) - 1);
        ++count;
    }
    ReleaseSRWLockExclusive(&gActionLock);
}

void LogDigitalTransition(ActionHandle handle, bool pressed, bool active) {
    if (!gLogPressedActions) {
        return;
    }

    char nameCopy[128]{};
    bool shouldLog = false;
    AcquireSRWLockExclusive(&gActionLock);
    for (std::size_t i = 0; i < gDigitalActionCount; ++i) {
        ActionRecord& record = gDigitalActions[i];
        if (record.handle != handle) {
            continue;
        }
        if (!record.hasLastPressed || record.lastPressed != pressed) {
            record.lastPressed = pressed;
            record.hasLastPressed = true;
            std::strncpy(nameCopy, record.name, sizeof(nameCopy) - 1);
            shouldLog = pressed;
        }
        break;
    }
    ReleaseSRWLockExclusive(&gActionLock);

    if (shouldLog) {
        Log("DIGITAL pressed: name=\"%s\" handle=0x%llx active=%d", nameCopy, static_cast<unsigned long long>(handle), active ? 1 : 0);
    }
}

ActionHandle __fastcall HookGetActionSetHandle(void* self, const char* name) {
    const ActionHandle handle = gOriginalGetActionSetHandle(self, name);
    if (gLogActionLookups) {
        Log("ACTION SET: name=\"%s\" handle=0x%llx", name ? name : "<null>", static_cast<unsigned long long>(handle));
    }
    return handle;
}

ActionHandle __fastcall HookGetDigitalActionHandle(void* self, const char* name) {
    const ActionHandle handle = gOriginalGetDigitalActionHandle(self, name);
    RememberAction(gDigitalActions, std::size(gDigitalActions), gDigitalActionCount, handle, name);
    if (gLogActionLookups) {
        Log("DIGITAL ACTION: name=\"%s\" handle=0x%llx", name ? name : "<null>", static_cast<unsigned long long>(handle));
    }
    return handle;
}

InputDigitalActionData __fastcall HookGetDigitalActionData(void* self, InputHandle input, ActionHandle action) {
    InputDigitalActionData data = gOriginalGetDigitalActionData(self, input, action);
    LogDigitalTransition(action, data.state, data.active);
    return data;
}

ActionHandle __fastcall HookGetAnalogActionHandle(void* self, const char* name) {
    const ActionHandle handle = gOriginalGetAnalogActionHandle(self, name);
    RememberAction(gAnalogActions, std::size(gAnalogActions), gAnalogActionCount, handle, name);
    if (gLogActionLookups) {
        Log("ANALOG ACTION: name=\"%s\" handle=0x%llx", name ? name : "<null>", static_cast<unsigned long long>(handle));
    }
    return handle;
}

InputAnalogActionData __fastcall HookGetAnalogActionData(void* self, InputHandle input, ActionHandle action) {
    return gOriginalGetAnalogActionData(self, input, action);
}

bool PatchVtableSlot(void** table, std::size_t index, void* replacement, void** original) {
    if (table[index] == replacement) {
        return true;
    }
    if (*original != nullptr) {
        Log("ERROR: refusing to patch vtable slot %zu twice with different tables.", index);
        return false;
    }

    DWORD oldProtection = 0;
    if (!VirtualProtect(&table[index], sizeof(void*), PAGE_EXECUTE_READWRITE, &oldProtection)) {
        return false;
    }
    *original = table[index];
    table[index] = replacement;
    FlushInstructionCache(GetCurrentProcess(), &table[index], sizeof(void*));
    DWORD ignored = 0;
    VirtualProtect(&table[index], sizeof(void*), oldProtection, &ignored);
    return true;
}

void FormatGuid(REFGUID guid, char* output, std::size_t outputSize) {
    if (!output || !outputSize) return;
    std::snprintf(
        output,
        outputSize,
        "%08lx-%04x-%04x-%02x%02x-%02x%02x%02x%02x%02x%02x",
        static_cast<unsigned long>(guid.Data1),
        guid.Data2,
        guid.Data3,
        guid.Data4[0], guid.Data4[1], guid.Data4[2], guid.Data4[3],
        guid.Data4[4], guid.Data4[5], guid.Data4[6], guid.Data4[7]);
}

DirectInputDeviceRecord* FindDirectInputDevice(void* device, bool create) {
    DirectInputDeviceRecord* empty = nullptr;
    for (DirectInputDeviceRecord& record : gDirectInputDevices) {
        if (record.device == device) return &record;
        if (!record.device && !empty) empty = &record;
    }
    if (create && empty) {
        empty->device = device;
        return empty;
    }
    return nullptr;
}

int DirectInputAxisBand(LONG value, LONG center) {
    const LONGLONG delta = static_cast<LONGLONG>(value) - static_cast<LONGLONG>(center);
    constexpr LONGLONG kThreshold = 10000;
    if (delta <= -kThreshold) return -1;
    if (delta >= kThreshold) return 1;
    return 0;
}

HRESULT STDMETHODCALLTYPE HookDirectInputSetDataFormat(void* self, LPCDIDATAFORMAT format) {
    const HRESULT result = gOriginalDirectInputSetDataFormat(self, format);
    if (FAILED(result) || !format) return result;

    DWORD buttonCount = 0;
    DWORD axisCount = 0;
    DWORD povCount = 0;
    AcquireSRWLockExclusive(&gDirectInputLock);
    DirectInputDeviceRecord* record = FindDirectInputDevice(self, true);
    if (record) {
        record->dataSize = format->dwDataSize;
        record->buttonCount = 0;
        record->axisCount = 0;
        record->povCount = 0;
        record->initialized = false;
        if (format->rgodf && format->dwObjSize >= sizeof(DIOBJECTDATAFORMAT)) {
            for (DWORD i = 0; i < format->dwNumObjs; ++i) {
                const BYTE* objectBase = reinterpret_cast<const BYTE*>(format->rgodf) + static_cast<std::size_t>(i) * format->dwObjSize;
                const auto* object = reinterpret_cast<const DIOBJECTDATAFORMAT*>(objectBase);
                const DWORD type = DIDFT_GETTYPE(object->dwType);
                if ((type & DIDFT_BUTTON) && record->buttonCount < std::size(record->buttonOffsets)) {
                    record->buttonOffsets[record->buttonCount++] = object->dwOfs;
                } else if ((type & DIDFT_AXIS) && record->axisCount < std::size(record->axisOffsets)) {
                    record->axisOffsets[record->axisCount++] = object->dwOfs;
                } else if ((type & DIDFT_POV) && record->povCount < std::size(record->povOffsets)) {
                    record->povOffsets[record->povCount++] = object->dwOfs;
                }
            }
        }
        buttonCount = record->buttonCount;
        axisCount = record->axisCount;
        povCount = record->povCount;
    }
    ReleaseSRWLockExclusive(&gDirectInputLock);

    Log(
        "DINPUT data format: device=%p size=%lu objects=%lu buttons=%lu axes=%lu pov=%lu",
        self,
        static_cast<unsigned long>(format->dwDataSize),
        static_cast<unsigned long>(format->dwNumObjs),
        static_cast<unsigned long>(buttonCount),
        static_cast<unsigned long>(axisCount),
        static_cast<unsigned long>(povCount));
    return result;
}

HRESULT STDMETHODCALLTYPE HookDirectInputGetDeviceState(void* self, DWORD size, LPVOID data) {
    const HRESULT result = gOriginalDirectInputGetDeviceState(self, size, data);
    if (FAILED(result) || !data || !gLogDirectInputTransitions) return result;

    bool changed = false;
    char pressed[512]{};
    char axes[256]{};
    char pov[128]{};
    std::strncpy(pressed, "<none>", sizeof(pressed) - 1);
    std::strncpy(axes, "<center>", sizeof(axes) - 1);
    std::strncpy(pov, "<center>", sizeof(pov) - 1);

    AcquireSRWLockExclusive(&gDirectInputLock);
    DirectInputDeviceRecord* record = FindDirectInputDevice(self, true);
    if (record) {
        const BYTE* bytes = static_cast<const BYTE*>(data);
        bool firstPressed = true;
        for (DWORD i = 0; i < record->buttonCount; ++i) {
            const DWORD offset = record->buttonOffsets[i];
            if (offset >= size) continue;
            const BYTE pressedNow = (bytes[offset] & 0x80) ? 1 : 0;
            if (!record->initialized || record->lastButtons[i] != pressedNow) changed = true;
            record->lastButtons[i] = pressedNow;
            if (pressedNow) {
                if (firstPressed) pressed[0] = '\0';
                char item[24]{};
                std::snprintf(item, sizeof(item), "%s%lu", firstPressed ? "" : "+", static_cast<unsigned long>(i));
                std::strncat(pressed, item, sizeof(pressed) - std::strlen(pressed) - 1);
                firstPressed = false;
            }
        }

        bool firstAxis = true;
        for (DWORD i = 0; i < record->axisCount; ++i) {
            const DWORD offset = record->axisOffsets[i];
            if (offset + sizeof(LONG) > size) continue;
            LONG value = 0;
            std::memcpy(&value, bytes + offset, sizeof(value));
            if (!record->initialized) record->axisCenters[i] = value;
            const int band = DirectInputAxisBand(value, record->axisCenters[i]);
            if (!record->initialized || record->lastAxisBands[i] != band) changed = true;
            record->lastAxisBands[i] = band;
            if (band) {
                if (firstAxis) axes[0] = '\0';
                char item[32]{};
                std::snprintf(item, sizeof(item), "%s%lu:%+d", firstAxis ? "" : ",", static_cast<unsigned long>(i), band);
                std::strncat(axes, item, sizeof(axes) - std::strlen(axes) - 1);
                firstAxis = false;
            }
        }

        bool firstPov = true;
        for (DWORD i = 0; i < record->povCount; ++i) {
            const DWORD offset = record->povOffsets[i];
            if (offset + sizeof(DWORD) > size) continue;
            DWORD value = 0;
            std::memcpy(&value, bytes + offset, sizeof(value));
            if (!record->initialized || record->lastPov[i] != value) changed = true;
            record->lastPov[i] = value;
            if (LOWORD(value) != 0xFFFF) {
                if (firstPov) pov[0] = '\0';
                char item[32]{};
                std::snprintf(item, sizeof(item), "%s%lu:%lu", firstPov ? "" : ",", static_cast<unsigned long>(i), static_cast<unsigned long>(value));
                std::strncat(pov, item, sizeof(pov) - std::strlen(pov) - 1);
                firstPov = false;
            }
        }
        record->initialized = true;
    }
    ReleaseSRWLockExclusive(&gDirectInputLock);

    if (changed) {
        Log("DINPUT state: device=%p size=%lu buttons=[%s] axes=[%s] pov=[%s]", self, static_cast<unsigned long>(size), pressed, axes, pov);
    }
    return result;
}

HRESULT STDMETHODCALLTYPE HookDirectInputCreateDevice(void* self, REFGUID deviceGuid, void** device, LPUNKNOWN outer) {
    const HRESULT result = gOriginalDirectInputCreateDevice(self, deviceGuid, device, outer);
    char guidText[64]{};
    FormatGuid(deviceGuid, guidText, sizeof(guidText));
    Log("DINPUT CreateDevice: guid=%s result=0x%08lx device=%p", guidText, static_cast<unsigned long>(result), device ? *device : nullptr);
    if (FAILED(result) || !device || !*device) return result;

    AcquireSRWLockExclusive(&gDirectInputLock);
    FindDirectInputDevice(*device, true);
    ReleaseSRWLockExclusive(&gDirectInputLock);

    void** vtable = *reinterpret_cast<void***>(*device);
    if (!vtable) return result;
    const bool stateOk = PatchVtableSlot(
        vtable,
        9,
        reinterpret_cast<void*>(&HookDirectInputGetDeviceState),
        reinterpret_cast<void**>(&gOriginalDirectInputGetDeviceState));
    const bool formatOk = PatchVtableSlot(
        vtable,
        11,
        reinterpret_cast<void*>(&HookDirectInputSetDataFormat),
        reinterpret_cast<void**>(&gOriginalDirectInputSetDataFormat));
    Log("DINPUT device hooks: device=%p GetDeviceState=%d SetDataFormat=%d", *device, stateOk ? 1 : 0, formatOk ? 1 : 0);
    return result;
}

HRESULT WINAPI HookDirectInput8Create(HINSTANCE instance, DWORD version, REFIID riid, LPVOID* output, LPUNKNOWN outer) {
    const HRESULT result = gOriginalDirectInput8Create(instance, version, riid, output, outer);
    Log("DINPUT DirectInput8Create: version=0x%04lx result=0x%08lx interface=%p", static_cast<unsigned long>(version), static_cast<unsigned long>(result), output ? *output : nullptr);
    if (FAILED(result) || !output || !*output) return result;

    void** vtable = *reinterpret_cast<void***>(*output);
    if (!vtable) return result;
    const bool ok = PatchVtableSlot(
        vtable,
        3,
        reinterpret_cast<void*>(&HookDirectInputCreateDevice),
        reinterpret_cast<void**>(&gOriginalDirectInputCreateDevice));
    Log("DINPUT interface hook: CreateDevice=%d", ok ? 1 : 0);
    return result;
}

bool InstallDirectInputHook() {
    const bool installed = InstallMainImportNameHook(
        "DINPUT8.dll",
        "DirectInput8Create",
        reinterpret_cast<void*>(&HookDirectInput8Create),
        reinterpret_cast<void**>(&gOriginalDirectInput8Create));
    if (!installed) {
        Log("NOTICE: DirectInput8Create import hook was not installed.");
        return false;
    }
    Log("DirectInput8Create hook installed. Device input will be observed read-only.");
    return true;
}

void* FindSteamInputInterface(HMODULE steamApi, const char** version) {
    using AccessorFn = void*(__cdecl*)();
    constexpr const char* accessors[] = {
        "SteamAPI_SteamInput_v006",
        "SteamAPI_SteamInput_v007",
    };

    for (const char* accessorName : accessors) {
        FARPROC address = GetProcAddress(steamApi, accessorName);
        if (!address) {
            continue;
        }
        AccessorFn accessor = nullptr;
        static_assert(sizeof(accessor) == sizeof(address));
        std::memcpy(&accessor, &address, sizeof(accessor));
        void* interfacePointer = accessor();
        if (interfacePointer) {
            *version = accessorName;
            return interfacePointer;
        }
    }
    return nullptr;
}

bool InstallSteamInputHooks() {
    HMODULE steamApi = GetModuleHandleW(L"steam_api64.dll");
    if (!steamApi) {
        return false;
    }

    const char* version = nullptr;
    void* steamInput = FindSteamInputInterface(steamApi, &version);
    if (!steamInput) {
        return false;
    }

    void** vtable = *reinterpret_cast<void***>(steamInput);
    if (!vtable) {
        return false;
    }

    // SteamInput006 and SteamInput007 share these slot positions.
    constexpr std::size_t kGetActionSetHandle = 9;
    constexpr std::size_t kGetDigitalActionHandle = 16;
    constexpr std::size_t kGetDigitalActionData = 17;
    constexpr std::size_t kGetAnalogActionHandle = 20;
    constexpr std::size_t kGetAnalogActionData = 21;

    bool ok = true;
    ok &= PatchVtableSlot(vtable, kGetActionSetHandle, reinterpret_cast<void*>(&HookGetActionSetHandle), reinterpret_cast<void**>(&gOriginalGetActionSetHandle));
    ok &= PatchVtableSlot(vtable, kGetDigitalActionHandle, reinterpret_cast<void*>(&HookGetDigitalActionHandle), reinterpret_cast<void**>(&gOriginalGetDigitalActionHandle));
    ok &= PatchVtableSlot(vtable, kGetDigitalActionData, reinterpret_cast<void*>(&HookGetDigitalActionData), reinterpret_cast<void**>(&gOriginalGetDigitalActionData));
    ok &= PatchVtableSlot(vtable, kGetAnalogActionHandle, reinterpret_cast<void*>(&HookGetAnalogActionHandle), reinterpret_cast<void**>(&gOriginalGetAnalogActionHandle));
    ok &= PatchVtableSlot(vtable, kGetAnalogActionData, reinterpret_cast<void*>(&HookGetAnalogActionData), reinterpret_cast<void**>(&gOriginalGetAnalogActionData));

    if (ok) {
        Log("Steam Input hooks installed through %s. interface=%p vtable=%p", version, steamInput, vtable);
    } else {
        Log("ERROR: one or more Steam Input vtable hooks failed.");
    }
    return ok;
}

DWORD WINAPI MainThread(void*) {
    InitializePaths();
    DeleteFileW(gLogPath);
    LoadConfiguration();

    Log("%s v%s loaded.", kModName, kVersion);
    Log(
        "Controller remap master switch is %s; DualSenseUSB=%d XInput=%d. Output/rumble/adaptive-trigger APIs remain untouched.",
        gEnableNativeRemap ? "ENABLED" : "DISABLED (read-only diagnostics)",
        gEnableDualSenseUsbRemap ? 1 : 0,
        gEnableXInputRemap ? 1 : 0);
    Log(
        "Style slots: Square=%d Triangle=%d Cross=%d (1=left, 2=down, 3=right).",
        gStyleSquareDirection,
        gStyleTriangleDirection,
        gStyleCrossDirection);
    Log("Configurable bindings loaded; PreserveL2R2Fire=%d.", gPreserveL2R2Fire ? 1 : 0);

    wchar_t exePath[MAX_PATH]{};
    GetModuleFileNameW(nullptr, exePath, MAX_PATH);
    char exeUtf8[MAX_PATH * 3]{};
    WideCharToMultiByte(CP_UTF8, 0, exePath, -1, exeUtf8, sizeof(exeUtf8), nullptr, nullptr);
    Log("Host executable: %s", exeUtf8);

    LogExecutableImports();
    LogNativeSnapshot("startup");
    InstallXInputHook();
    InstallDirectInputHook();
    InstallHidHooks();

    constexpr DWORD kTimeoutMs = 120000;
    constexpr DWORD kIntervalMs = 100;
    DWORD waited = 0;
    bool steamInputHooked = false;
    bool logged10Seconds = false;
    bool logged30Seconds = false;
    while (waited < kTimeoutMs) {
        if (!steamInputHooked && InstallSteamInputHooks()) {
            steamInputHooked = true;
            Log("Steam Input diagnostics are also active. They are optional when Steam Input is disabled.");
        }
        if (!logged10Seconds && waited >= 10000) {
            LogNativeSnapshot("10-seconds");
            logged10Seconds = true;
            Log("Ready. Keep Steam Input disabled for the native DualSense path, then test the configured combinations.");
        }
        if (!logged30Seconds && waited >= 30000) {
            LogNativeSnapshot("30-seconds");
            logged30Seconds = true;
            if (steamInputHooked) {
                Log("Diagnostics initialized. Native output/haptics have not been intercepted.");
                return 0;
            }
        }
        Sleep(kIntervalMs);
        waited += kIntervalMs;
    }

    Log("NOTICE: Steam Input interface was not available after %lu ms; this is expected when Steam Input is disabled.", static_cast<unsigned long>(kTimeoutMs));
    Log("Native device/module diagnostics completed. Native output/haptics have not been intercepted.");
    return 0;
}

} // namespace

BOOL APIENTRY DllMain(HMODULE module, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        gThisModule = module;
        DisableThreadLibraryCalls(module);
        HANDLE thread = CreateThread(nullptr, 0, MainThread, nullptr, 0, nullptr);
        if (thread) {
            CloseHandle(thread);
        }
    }
    return TRUE;
}
