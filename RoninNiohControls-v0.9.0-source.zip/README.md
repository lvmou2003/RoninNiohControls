# Ronin Nioh Controls

《浪人崛起》PC 版的仁王式手柄操作 Mod。

## 当前版本：0.9.0-configurable-bindings

本版同时支持两条输入链路：已经实机验证的 DualSense / DualSense Edge 有线 USB HID，以及《浪人崛起》使用的 XInput 1.4。XInput 覆盖 Xbox 360 / One / Series 手柄、绝大多数第三方 PC 手柄，以及通过 Steam Input 或 DS4Windows 转换成 XInput 的 PlayStation / Switch 手柄。

两条链路都只改写游戏即将消费的输入状态。DualSense 的 `WriteFile`、XInput 的 `XInputSetState`、震动和自适应扳机输出均不挂接。原生 USB DualSense 可保持游戏原生输出；通过 Steam Input / DS4Windows 转换时，能否保留原生触觉取决于转换软件，不是本 Mod 控制的。

v0.9.0 起，每个 Mod 动作的物理入口都可在 INI 的 `[Bindings]` 中修改，支持 PS/Xbox 按键别名、单键、多键组合和 `None` 禁用。完整按键名、优先级、冲突规则和示例见 `使用说明.md`。

若要立即回到只读诊断，将 INI 中 `[Remap]` 的 `Enable = 0`。也可用 `EnableDualSenseUsb` 和 `EnableXInput` 单独关闭某一后端。当前不修改未验证的 DualSense 蓝牙报告，也不假设所有冷门原生 DirectInput/HID 手柄具有相同数据布局。

关闭 Steam Input 是受支持的测试方式。最终 Mod 的目标是在游戏进程内部、战斗系统消费指令之前改写输入动作，不创建虚拟 Xbox 手柄，也不使用 DS4Windows/ViGEm，因此游戏到实体 DualSense 的原生输出链路可以保持不变。

## 安装

1. 把压缩包里的文件解压到 `Ronin.exe` 所在目录。压缩包已经包含 64 位 Ultimate ASI Loader（`dinput8.dll`）。
   - 如果目录中已经存在 `dinput8.dll`，不要直接覆盖；现有文件很可能已经是 ASI Loader，只复制本 Mod 的 `.asi` 和 `.ini` 即可。
2. 把 `RoninNiohControls.asi` 和 `RoninNiohControls.ini` 放进同一目录。
3. 按手柄类型选择：
   - DualSense / Edge 有线：建议关闭 Steam Input，以保留原生输出。
   - Xbox / XInput 手柄：直接使用。
   - Switch、DualShock 4 或其他手柄：可由 Steam Input / DS4Windows 转为 XInput。
4. 顺序不限，先在安全区域确认普通移动、菜单和○闪避，再分别测试 R2、L2+R2、L1+□/△/×、R1+□/△/×、R1+○、R1 单按、烈风和紫电。
5. 退出游戏，把同目录生成的 `RoninNiohControls.log` 发回分析。

日志只包含程序模块、控制器设备标识、输入状态和 `REMAP` 触发名称，不记录聊天、账号、存档内容。

测试成功后，将 INI 中 `[Diagnostics]` 的 `EnableFileLog = 0`，重启游戏即可完全停止写入 `RoninNiohControls.log`；映射仍然正常工作。

## 目标键位

| 输入 | 目标动作 |
| --- | --- |
| L1 | 防御 |
| R2（未瞄准） | 石火 |
| △ | 钩爪（原 R2 单按动作） |
| L2 + R2 | 远程射击 |
| L1 + □ / △ / × | 三个武技 |
| L1 + R1 | 秘传武技（原 R1 + ○） |
| R1 + □ / △ / × | 三个流派槽位；攻击衔接窗口中正常触发烈风 |
| R1 + ○ | 切换武器；攻击衔接窗口中正常触发紫电 |
| R1 | 保留原版闪刃 |
| ○ | 闪避 |

`△` 单按会转成原 R2 的钩爪动作；`L1+△` 和 `R1+△` 优先使用上表的武技/流派映射。

流派使用游戏原生的右摇杆左/下/右三个槽位。默认为 `□=左、×=下、△=右`，可通过 INI 中的 `Style...Direction` 修改：`1=左、2=下、3=右`。

Xbox 键位对应为 `L1=LB、R1=RB、□=X、△=Y、×=A、○=B、L2=LT、R2=RT`。

## 兼容性边界

- 原生 DualSense USB：已实机验证。
- XInput：已接入同一套映射，需用 Xbox/第三方手柄实机验证。
- DualSense 蓝牙原生模式：暂不改写，因为报告带 CRC，在没有实机日志前不冒险破坏输入。
- 只提供冷门 DirectInput 或私有 HID 模式的手柄：暂不保证；可转为 XInput 后使用。

## 卸载

删除 `RoninNiohControls.asi`、`RoninNiohControls.ini` 和 `RoninNiohControls.log` 即可。若没有其他 ASI Mod，再删除 `dinput8.dll`。

## 构建

在 PowerShell 中运行：

```powershell
.\build.ps1 -Configuration Release
```

工程使用便携 Zig 0.15.2 的 Clang 前端生成 64 位 Windows DLL，不依赖 Visual Studio。
构建脚本会依次查找项目内 `toolchains\zig-x86_64-windows-0.15.2\zig.exe`、项目同级的同名工具链，以及系统 `PATH` 中的 `zig`；分享源码时不需要保留作者电脑上的目录结构。

## 第三方组件

发布包包含 ThirteenAG 的 Ultimate ASI Loader v9.7.4，遵循 MIT License；许可证随包提供。
