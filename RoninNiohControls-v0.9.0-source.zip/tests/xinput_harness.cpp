#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <xinput.h>

using SetTestGamepadStateFn = void(WINAPI*)(WORD, BYTE, BYTE);

bool ReadState(SetTestGamepadStateFn setState, WORD buttons, BYTE leftTrigger, BYTE rightTrigger, XINPUT_GAMEPAD& output) {
    setState(buttons, leftTrigger, rightTrigger);
    XINPUT_STATE state{};
    if (XInputGetState(0, &state) != ERROR_SUCCESS) return false;
    output = state.Gamepad;
    return true;
}

int wmain(int argc, wchar_t** argv) {
    if (argc != 2) return 2;

    HMODULE xinput = GetModuleHandleW(L"xinput1_4.dll");
    if (!xinput) return 3;
    auto setState = reinterpret_cast<SetTestGamepadStateFn>(GetProcAddress(xinput, "SetTestGamepadState"));
    if (!setState) return 4;

    if (!LoadLibraryW(argv[1])) return 5;
    Sleep(250);

    XINPUT_GAMEPAD gamepad{};
    if (!ReadState(setState, 0, 0, 200, gamepad)) return 10;
    if (gamepad.bRightTrigger != 0 || !(gamepad.wButtons & XINPUT_GAMEPAD_Y)) return 11;

    if (!ReadState(setState, 0, 200, 200, gamepad)) return 12;
    if (gamepad.bRightTrigger != 200 || (gamepad.wButtons & XINPUT_GAMEPAD_Y)) return 13;

    if (!ReadState(setState, XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_X, 0, 0, gamepad)) return 14;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_X)) return 15;

    if (!ReadState(setState, XINPUT_GAMEPAD_RIGHT_SHOULDER | XINPUT_GAMEPAD_X, 0, 0, gamepad)) return 16;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_X) || gamepad.sThumbRX >= -30000 || gamepad.sThumbRY != 0) return 17;

    if (!ReadState(setState, XINPUT_GAMEPAD_RIGHT_SHOULDER | XINPUT_GAMEPAD_Y, 0, 0, gamepad)) return 18;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_Y) || gamepad.sThumbRX <= 30000 || gamepad.sThumbRY != 0) return 19;

    if (!ReadState(setState, XINPUT_GAMEPAD_RIGHT_SHOULDER | XINPUT_GAMEPAD_A, 0, 0, gamepad)) return 20;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_A) || gamepad.sThumbRY >= -30000 || gamepad.sThumbRX != 0) return 21;

    if (!ReadState(setState, XINPUT_GAMEPAD_RIGHT_SHOULDER | XINPUT_GAMEPAD_B, 0, 0, gamepad)) return 22;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_B) || !(gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) return 23;

    if (!ReadState(setState, XINPUT_GAMEPAD_B, 0, 0, gamepad)) return 24;
    if (!(gamepad.wButtons & XINPUT_GAMEPAD_B)) return 25;

    if (!ReadState(setState, XINPUT_GAMEPAD_RIGHT_SHOULDER, 0, 0, gamepad)) return 26;
    if (gamepad.wButtons != XINPUT_GAMEPAD_RIGHT_SHOULDER) return 27;

    if (!ReadState(setState, XINPUT_GAMEPAD_Y, 0, 0, gamepad)) return 28;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_Y) || gamepad.bRightTrigger != 255) return 29;

    if (!ReadState(setState, XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_Y, 0, 0, gamepad)) return 30;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_Y) ||
        gamepad.bRightTrigger != 0) return 31;

    if (!ReadState(
            setState,
            XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_RIGHT_SHOULDER,
            0,
            0,
            gamepad)) return 32;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_B)) return 33;

    Sleep(100);
    return 0;
}
