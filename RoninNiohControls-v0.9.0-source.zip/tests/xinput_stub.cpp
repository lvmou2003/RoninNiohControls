#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <xinput.h>

namespace {
XINPUT_STATE gState{};
}

extern "C" __declspec(dllexport) void WINAPI SetTestGamepadState(WORD buttons, BYTE leftTrigger, BYTE rightTrigger) {
    ++gState.dwPacketNumber;
    gState.Gamepad = {};
    gState.Gamepad.wButtons = buttons;
    gState.Gamepad.bLeftTrigger = leftTrigger;
    gState.Gamepad.bRightTrigger = rightTrigger;
}

extern "C" DWORD WINAPI FakeXInputGetState(DWORD userIndex, XINPUT_STATE* state) {
    if (userIndex != 0 || !state) return ERROR_DEVICE_NOT_CONNECTED;
    *state = gState;
    return ERROR_SUCCESS;
}

extern "C" DWORD WINAPI FakeXInputSetState(DWORD, XINPUT_VIBRATION*) {
    return ERROR_SUCCESS;
}

BOOL WINAPI DllMain(HINSTANCE, DWORD, LPVOID) {
    return TRUE;
}
