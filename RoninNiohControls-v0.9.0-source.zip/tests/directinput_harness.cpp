#define WIN32_LEAN_AND_MEAN
#define DIRECTINPUT_VERSION 0x0800
#include <windows.h>
#include <dinput.h>

int wmain(int argc, wchar_t** argv) {
    if (argc != 2) return 2;
    if (!LoadLibraryW(argv[1])) return 3;
    Sleep(250);

    IDirectInput8W* input = nullptr;
    HRESULT result = DirectInput8Create(
        GetModuleHandleW(nullptr),
        DIRECTINPUT_VERSION,
        IID_IDirectInput8W,
        reinterpret_cast<void**>(&input),
        nullptr);
    if (FAILED(result) || !input) return 4;

    IDirectInputDevice8W* keyboard = nullptr;
    result = input->CreateDevice(GUID_SysKeyboard, &keyboard, nullptr);
    if (SUCCEEDED(result) && keyboard) {
        keyboard->SetDataFormat(&c_dfDIKeyboard);
        keyboard->Acquire();
        BYTE state[256]{};
        keyboard->GetDeviceState(sizeof(state), state);
        keyboard->Unacquire();
        keyboard->Release();
    }
    input->Release();
    Sleep(250);
    return 0;
}
