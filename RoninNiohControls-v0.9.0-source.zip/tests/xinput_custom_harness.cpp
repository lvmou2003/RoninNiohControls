#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <xinput.h>

using SetTestGamepadStateFn = void(WINAPI*)(WORD, BYTE, BYTE);

bool ReadState(SetTestGamepadStateFn setState, WORD buttons, BYTE leftTrigger, BYTE rightTrigger, XINPUT_GAMEPAD& output) {
    setState(buttons, leftTrigger, rightTrigger);
    XINPUT_STATE state{};
    if (XInputGetState(0, &state) != ERROR_SUCCESS) return false;
    output = state.Gamepad;
    return true;
}

int wmain(int argc, wchar_t** argv) {
    if (argc != 2) return 2;
    HMODULE xinput = GetModuleHandleW(L"xinput1_4.dll");
    if (!xinput) return 3;
    auto setState = reinterpret_cast<SetTestGamepadStateFn>(GetProcAddress(xinput, "SetTestGamepadState"));
    if (!setState) return 4;
    if (!LoadLibraryW(argv[1])) return 5;
    Sleep(250);

    XINPUT_GAMEPAD gamepad{};

    // Xbox alias B -> Counterspark output Y.
    if (!ReadState(setState, XINPUT_GAMEPAD_B, 0, 0, gamepad)) return 10;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_B) || !(gamepad.wButtons & XINPUT_GAMEPAD_Y)) return 11;

    // RS -> original RT/Grappling Hook.
    if (!ReadState(setState, XINPUT_GAMEPAD_RIGHT_THUMB, 0, 0, gamepad)) return 12;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_THUMB) || gamepad.bRightTrigger != 255) return 13;

    // Spaces and aliases: LT + X -> RB + X.
    if (!ReadState(setState, XINPUT_GAMEPAD_X, 200, 0, gamepad)) return 14;
    if (gamepad.bLeftTrigger != 0 ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_X)) return 15;

    // None disables MartialTriangle, so LB+Y remains untouched.
    if (!ReadState(setState, XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_Y, 0, 0, gamepad)) return 16;
    if (gamepad.wButtons != (XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_Y)) return 17;

    // LB+RB -> original RB+B Veiled Art.
    if (!ReadState(setState, XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_RIGHT_SHOULDER, 0, 0, gamepad)) return 18;
    if ((gamepad.wButtons & XINPUT_GAMEPAD_LEFT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_B)) return 19;

    // StyleSquare and StyleTriangle deliberately share View+X. Equal-size ties
    // follow the documented fixed order, so StyleSquare -> style-left wins.
    if (!ReadState(setState, XINPUT_GAMEPAD_BACK | XINPUT_GAMEPAD_X, 0, 0, gamepad)) return 20;
    if ((gamepad.wButtons & (XINPUT_GAMEPAD_BACK | XINPUT_GAMEPAD_X)) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        gamepad.sThumbRX >= -30000) return 21;

    // RS+A is more specific than RS, so StyleCross wins over GrapplingHook.
    if (!ReadState(setState, XINPUT_GAMEPAD_RIGHT_THUMB | XINPUT_GAMEPAD_A, 0, 0, gamepad)) return 22;
    if ((gamepad.wButtons & (XINPUT_GAMEPAD_RIGHT_THUMB | XINPUT_GAMEPAD_A)) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        gamepad.sThumbRY >= -30000 || gamepad.bRightTrigger != 0) return 23;

    // LB+B -> original RB+DPadUp weapon switch / Flash Attack.
    if (!ReadState(setState, XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_B, 0, 0, gamepad)) return 24;
    if ((gamepad.wButtons & (XINPUT_GAMEPAD_LEFT_SHOULDER | XINPUT_GAMEPAD_B)) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_RIGHT_SHOULDER) ||
        !(gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)) return 25;

    Sleep(100);
    return 0;
}
