#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <hidsdi.h>

int wmain(int argc, wchar_t** argv) {
    if (argc != 2) return 2;
    if (!LoadLibraryW(argv[1])) return 3;
    Sleep(250);

    HANDLE file = CreateFileW(
        L"NUL",
        GENERIC_READ,
        FILE_SHARE_READ | FILE_SHARE_WRITE,
        nullptr,
        OPEN_EXISTING,
        FILE_ATTRIBUTE_NORMAL,
        nullptr);
    if (file == INVALID_HANDLE_VALUE) return 4;

    HIDD_ATTRIBUTES attributes{};
    attributes.Size = sizeof(attributes);
    HidD_GetAttributes(file, &attributes);
    BYTE data[64]{};
    DWORD read = 0;
    ReadFile(file, data, sizeof(data), &read, nullptr);
    CloseHandle(file);

    OVERLAPPED probe{};
    DWORD transferred = 0;
    GetOverlappedResult(INVALID_HANDLE_VALUE, &probe, &transferred, FALSE);
    GetOverlappedResultEx(INVALID_HANDLE_VALUE, &probe, &transferred, 0, FALSE);

    ULONG_PTR completionKey = 0;
    LPOVERLAPPED completed = nullptr;
    GetQueuedCompletionStatus(INVALID_HANDLE_VALUE, &transferred, &completionKey, &completed, 0);
    OVERLAPPED_ENTRY entry{};
    ULONG removed = 0;
    GetQueuedCompletionStatusEx(INVALID_HANDLE_VALUE, &entry, 1, &removed, 0, FALSE);
    Sleep(250);
    return 0;
}
