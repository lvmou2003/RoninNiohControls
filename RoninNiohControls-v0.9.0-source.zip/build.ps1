param(
    [ValidateSet('Debug', 'Release')]
    [string]$Configuration = 'Release'
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$outputDir = Join-Path $projectRoot 'build'
$dllPath = Join-Path $outputDir 'RoninNiohControls.dll'
$asiPath = Join-Path $outputDir 'RoninNiohControls.asi'
$env:ZIG_GLOBAL_CACHE_DIR = Join-Path $projectRoot '.zig-global-cache'
$env:ZIG_LOCAL_CACHE_DIR = Join-Path $projectRoot '.zig-local-cache'

$zigCandidates = @(
    (Join-Path $projectRoot 'toolchains\zig-x86_64-windows-0.15.2\zig.exe'),
    (Join-Path (Split-Path -Parent $projectRoot) 'toolchains\zig-x86_64-windows-0.15.2\zig.exe')
)
$zig = $zigCandidates | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
if (-not $zig) {
    $zigCommand = Get-Command zig.exe -ErrorAction SilentlyContinue
    if (-not $zigCommand) {
        $zigCommand = Get-Command zig -ErrorAction SilentlyContinue
    }
    if ($zigCommand) {
        $zig = $zigCommand.Source
    }
}
if (-not $zig) {
    throw 'Zig compiler not found. Install Zig 0.15.x and add it to PATH, or place it in toolchains\zig-x86_64-windows-0.15.2\zig.exe.'
}

New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
New-Item -ItemType Directory -Path $env:ZIG_GLOBAL_CACHE_DIR -Force | Out-Null
New-Item -ItemType Directory -Path $env:ZIG_LOCAL_CACHE_DIR -Force | Out-Null

$arguments = @(
    'c++',
    '-target', 'x86_64-windows-gnu',
    '-std=c++20',
    '-shared',
    '-DUNICODE',
    '-D_UNICODE',
    '-Wl,--subsystem,windows',
    '-luser32',
    (Join-Path $projectRoot 'src\dllmain.cpp'),
    '-o', $dllPath
)

if ($Configuration -eq 'Release') {
    $arguments += @('-O2', '-s')
} else {
    $arguments += @('-O0', '-g')
}

& $zig @arguments
if ($LASTEXITCODE -ne 0) {
    throw "Build failed with exit code $LASTEXITCODE"
}

Copy-Item -LiteralPath $dllPath -Destination $asiPath -Force
Remove-Item -LiteralPath $dllPath -Force
Copy-Item -LiteralPath (Join-Path $projectRoot 'RoninNiohControls.ini') -Destination $outputDir -Force
Write-Output "Built: $asiPath"
